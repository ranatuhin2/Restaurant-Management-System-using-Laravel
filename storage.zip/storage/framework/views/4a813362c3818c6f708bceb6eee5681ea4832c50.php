
<?php $__env->startSection('content'); ?>
    <div class="container">
    <div class="text-center mb-4">
         <h3>Edit Menu</h3>
         <p class="text-muted">Complete the form below to update</p>
      </div>
       <?php if(isset($data)): ?>
       <div class="container d-flex justify-content-center">
        <form action="<?php echo e(route('admin::update-team')); ?>" method="post" enctype="multipart/form-data" style="width:50vw; min-width:300px;" >
        <?php echo csrf_field(); ?>
            <div class="form-group">
                
                <input type="hidden" class="form-control"  name="id" value="<?php echo e($data->id); ?>" >
            </div>
            <div class="form-group">
                <label class="form-label" >Items Name</label>
                <input type="text" class="form-control"  name="name"  value="<?php echo e($data->Items); ?>" >
            </div>
            <div class="form-group">
                <label class="form-label">Items-Id</label>
                <input type="text" class="form-control"  name="Item_id" value="<?php echo e($data->Item_id); ?>" >
            </div>
            <div class="form-group">
                <label class="form-label" >Price</label>
                <input type="text" class="form-control"  name="price"  value="<?php echo e($data->price); ?>" >
            </div>
            <div class="form-group">
                <label>Description</label>
                <input type="text" class="form-control"  name="description"  value="<?php echo e($data->description); ?>" >
            </div>
            <div class="form-group">
                <label class="form-label" >Image</label>
                <input type="file"  class="form-control" name="image"  ><br>
                <img src="<?php echo e(url('/')); ?>/upload_file/<?php echo e($data->image); ?>" height="55px">
            </div>
            <div class="form-group">
                <label class="form-label">Category</label>
                <input type="text"  class="form-control" name="category" value="<?php echo e($data->category); ?>" >
            </div>
            <div class="from-group">
                <button class="btn btn-sm btn-primary" >Submit</button>
            </div>
        </form>
</div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\adminTempLaravel8\adminTempLaravel8\resources\views/admin/pages/menu/edit.blade.php ENDPATH**/ ?>