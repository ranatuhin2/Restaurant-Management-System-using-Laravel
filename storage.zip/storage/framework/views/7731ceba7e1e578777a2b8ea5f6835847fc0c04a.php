<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="card card-warning">
            <div class="card-header">
                <h3 class="card-title">Edit Contact Info</h3>
            </div>
        <?php echo $__env->make('admin.layout.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- /.card-header -->
            <div class="card-body">
                <form action="<?php echo e(route('admin::update_contact_info',$data['id'])); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Email</label><span style="color:red;">*</span>
                                <input type="text" name="email" class="form-control" placeholder="Enter ..." value="<?php echo e($data['email']); ?>">
                            </div>
                            <?php if($errors->has('email')): ?>
                                <span class="alert alert-danger"><?php echo e($errors->first('email')); ?></span>
                            <?php endif; ?>
                        </div>

                    <div class="col-sm-6">
                            <div class="form-group">
                                <label>Website</label><span style="color:red;">*</span>
                                <input type="text" name="website" class="form-control" placeholder="Enter ..." value="<?php echo e($data['website']); ?>">
                            </div>
                            <?php if($errors->has('website')): ?>
                                <span class="alert alert-danger"><?php echo e($errors->first('website')); ?></span>
                            <?php endif; ?>

                        </div>
                    </div>
                    <br>

                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Phone Code</label><span style="color:red;">*</span>
                                <input type="text" name="phone_code" class="form-control" placeholder="Enter ..." value="<?php echo e($data['phone_code']); ?>">
                            </div>
                            <?php if($errors->has('phone_code')): ?>
                                <span class="alert alert-danger"><?php echo e($errors->first('phone_code')); ?></span>
                            <?php endif; ?>

                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Phone</label><span style="color:red;">*</span>
                                <input type="text" name="phone" class="form-control" placeholder="Enter ..." value="<?php echo e($data['phone']); ?>">
                            </div>
                            <?php if($errors->has('phone')): ?>
                                <span class="alert alert-danger"><?php echo e($errors->first('phone')); ?></span>
                            <?php endif; ?>

                        </div>
                    </div>
                    <br>

                    <div class="row">
                        <div class="col-sm-12">

                            <div class="form-group">
                                <label>Address</label><span style="color:red;">*</span>
                                <textarea name="address" class="form-control" rows="5" cols="50" placeholder="Enter ..."><?php echo e($data['address']); ?></textarea>
                            </div>
                            <?php if($errors->has('address')): ?>
                                <span class="alert alert-danger"><?php echo e($errors->first('address')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <!-- input states -->

                    <div class="row">

                        <div class="col-md-12">
                            <div class="form-group" style="text-align:center">
                                <input type="submit" value="Submit" class="btn btn-primary">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!-- /.card-body -->
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\e122699\resources\views/admin/pages/contact_info/edit.blade.php ENDPATH**/ ?>