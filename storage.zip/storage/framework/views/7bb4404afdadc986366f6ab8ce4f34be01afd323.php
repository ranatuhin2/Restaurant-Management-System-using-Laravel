<?php $__env->startSection('content'); ?>
    <div class="content-wrapper" style="min-height: 357px;">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Site Information</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin::dashboard')); ?>">Dashboard</a> </li>
                            <li class="breadcrumb-item active">Site Information</li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Site Information</h3>
                                
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                    <tr>
                                        <th>Key</th>
                                        <th>Image</th>
                                        <th>Value</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php if(!empty($siteInfo)): ?>
                                        <?php $__currentLoopData = $siteInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($site['key']); ?></td>
                                                <td>
                                                    <?php if($site['is_image'] == 'Yes'): ?>
                                                        <img src="<?php echo e($site['value']); ?>" style="width: 120px;height: 50px;">
                                                    <?php else: ?>
                                                        <span>N/A</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if($site['is_image'] == 'Yes'): ?>
                                                        <span>N/A</span>
                                                    <?php else: ?>
                                                        <?php echo e($site['value']); ?>

                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <a href="<?php echo e(route('admin::information_edit',['id'=>$site['id']])); ?>" class="btn btn-warning btn-sm"><i class="fa fa-edit"></i> </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    </tbody>
                                    <tfoot>
                                    <tr>
                                        <th>Key</th>
                                        <th>Image</th>
                                        <th>Value</th>
                                        <th>Action</th>
                                    </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
    </div>
    <?php $__env->startPush('scripts'); ?>

    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\122687\resources\views/admin/pages/site_info/index.blade.php ENDPATH**/ ?>