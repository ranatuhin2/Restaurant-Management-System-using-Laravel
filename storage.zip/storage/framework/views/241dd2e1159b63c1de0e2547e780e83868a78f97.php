<?php $__env->startSection('content'); ?>
<div class="inner-banner">
    <img src="<?php echo e(url('/')); ?>/frontend/assets/images/product.webp" alt="">
    <div class="banner-content">
        <h3>Services</h3>
        <ol class="breadcrumb">


            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a>

            </li>





            <li class="breadcrumb-item active" aria-current="page">Services</li>


        </ol>
    </div>
</div>


<?php
$service_heading = \App\Models\Cms::where('key','our_services')
    ->where('status','Active')->select('title','description')->first();
if(!empty($service_heading)) {
    $explode1 = explode(' ', $service_heading['title']);

    if (count($explode1) > 1) {
        $s_title1 = $explode1[0];
        unset($explode1[0]);
        $s_title2 = implode(' ', $explode1);

    }else{
        $s_title1 = implode(' ', $explode1);
        $s_title2 = ' ';
    }
}
?>

<div class="our-classes section gap">
    <div class="container">
        <?php if(!empty($service_heading)): ?>
        <div class="head">
            <!-- <p class="tag">Our Classes</p> -->
            <h2><?php echo e($s_title1 ?? ""); ?> <span><?php echo e($s_title2 ?? ""); ?></span></h2>
            <p class="description"><?php echo e($service_heading['description'] ?? ""); ?></p>
        </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-lg-4 col-md-6">
                <div class="card-item">
                    <div class="image">
                        <img src="<?php echo e(url('/')); ?>/frontend/assets/images/product1.webp" alt="" loading="lazy">
                    </div>
                    <div class="text">
                        <div class="content">
                            <h3>Flanging & Advanced Pressing</h3>
                            <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the</p>
                        </div>
                        <!-- <div class="left">


                                <h4>
                                <svg width="25" height="15" viewBox="0 0 25 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M13.75 8.75H13.125V5.3125C13.125 5.13984 12.9852 5 12.8125 5H12.282C12.0969 5 11.916 5.05469 11.7621 5.15742L11.1633 5.55664C11.1291 5.57938 11.0998 5.60863 11.0769 5.64271C11.0541 5.67679 11.0382 5.71504 11.0301 5.75527C11.0221 5.7955 11.022 5.83693 11.03 5.87718C11.038 5.91743 11.0538 5.95571 11.0766 5.98984L11.4234 6.50977C11.4462 6.54392 11.4754 6.57325 11.5095 6.5961C11.5436 6.61894 11.5818 6.63484 11.6221 6.6429C11.6623 6.65095 11.7037 6.651 11.744 6.64303C11.7842 6.63507 11.8225 6.61925 11.8566 6.59648L11.875 6.58437V8.75H11.25C11.0773 8.75 10.9375 8.88984 10.9375 9.0625V9.6875C10.9375 9.86016 11.0773 10 11.25 10H13.75C13.9227 10 14.0625 9.86016 14.0625 9.6875V9.0625C14.0625 8.88984 13.9227 8.75 13.75 8.75ZM23.75 0H1.25C0.559766 0 0 0.559766 0 1.25V13.75C0 14.4402 0.559766 15 1.25 15H23.75C24.4402 15 25 14.4402 25 13.75V1.25C25 0.559766 24.4402 0 23.75 0ZM1.875 13.125V10.625C3.25586 10.625 4.375 11.7441 4.375 13.125H1.875ZM1.875 4.375V1.875H4.375C4.375 3.25586 3.25586 4.375 1.875 4.375ZM12.5 11.875C10.4289 11.875 8.75 9.91602 8.75 7.5C8.75 5.08359 10.4289 3.125 12.5 3.125C14.5711 3.125 16.25 5.08359 16.25 7.5C16.25 9.9168 14.5703 11.875 12.5 11.875ZM23.125 13.125H20.625C20.625 11.7441 21.7441 10.625 23.125 10.625V13.125ZM23.125 4.375C21.7441 4.375 20.625 3.25586 20.625 1.875H23.125V4.375Z" fill="black"/>
                                </svg>
                                 from 300$</h4>
                        </div> -->
                        <div class="right">
                            <div class="btn">Read More</div>
                        </div>
                    </div>
                </div>

            </div>

            <div class="col-lg-4 col-md-6">
                <div class="card-item">
                    <div class="image">
                        <img src="<?php echo e(url('/')); ?>/frontend/assets/images/process.webp" alt="" loading="lazy">
                    </div>
                    <div class="text">
                        <div class="content">
                            <h3>Metal Sheet Cutting</h3>
                            <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the</p>
                        </div>
                        <!-- <div class="left">


                                <h4>
                                <svg width="25" height="15" viewBox="0 0 25 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M13.75 8.75H13.125V5.3125C13.125 5.13984 12.9852 5 12.8125 5H12.282C12.0969 5 11.916 5.05469 11.7621 5.15742L11.1633 5.55664C11.1291 5.57938 11.0998 5.60863 11.0769 5.64271C11.0541 5.67679 11.0382 5.71504 11.0301 5.75527C11.0221 5.7955 11.022 5.83693 11.03 5.87718C11.038 5.91743 11.0538 5.95571 11.0766 5.98984L11.4234 6.50977C11.4462 6.54392 11.4754 6.57325 11.5095 6.5961C11.5436 6.61894 11.5818 6.63484 11.6221 6.6429C11.6623 6.65095 11.7037 6.651 11.744 6.64303C11.7842 6.63507 11.8225 6.61925 11.8566 6.59648L11.875 6.58437V8.75H11.25C11.0773 8.75 10.9375 8.88984 10.9375 9.0625V9.6875C10.9375 9.86016 11.0773 10 11.25 10H13.75C13.9227 10 14.0625 9.86016 14.0625 9.6875V9.0625C14.0625 8.88984 13.9227 8.75 13.75 8.75ZM23.75 0H1.25C0.559766 0 0 0.559766 0 1.25V13.75C0 14.4402 0.559766 15 1.25 15H23.75C24.4402 15 25 14.4402 25 13.75V1.25C25 0.559766 24.4402 0 23.75 0ZM1.875 13.125V10.625C3.25586 10.625 4.375 11.7441 4.375 13.125H1.875ZM1.875 4.375V1.875H4.375C4.375 3.25586 3.25586 4.375 1.875 4.375ZM12.5 11.875C10.4289 11.875 8.75 9.91602 8.75 7.5C8.75 5.08359 10.4289 3.125 12.5 3.125C14.5711 3.125 16.25 5.08359 16.25 7.5C16.25 9.9168 14.5703 11.875 12.5 11.875ZM23.125 13.125H20.625C20.625 11.7441 21.7441 10.625 23.125 10.625V13.125ZM23.125 4.375C21.7441 4.375 20.625 3.25586 20.625 1.875H23.125V4.375Z" fill="black"/>
                                </svg>
                                 from 300$</h4>
                        </div> -->
                        <div class="right">
                            <div class="btn">Read More</div>
                        </div>
                    </div>
                </div>

            </div>
            <div class="col-lg-4 col-md-6">
                <div class="card-item">
                    <div class="image">
                        <img src="<?php echo e(url('/')); ?>/frontend/assets/images/welding.webp" alt="" loading="lazy">
                    </div>
                    <div class="text">
                        <div class="content">
                            <h3>Machine Welding</h3>
                            <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the</p>
                        </div>
                        <!-- <div class="left">


                                <h4>
                                <svg width="25" height="15" viewBox="0 0 25 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M13.75 8.75H13.125V5.3125C13.125 5.13984 12.9852 5 12.8125 5H12.282C12.0969 5 11.916 5.05469 11.7621 5.15742L11.1633 5.55664C11.1291 5.57938 11.0998 5.60863 11.0769 5.64271C11.0541 5.67679 11.0382 5.71504 11.0301 5.75527C11.0221 5.7955 11.022 5.83693 11.03 5.87718C11.038 5.91743 11.0538 5.95571 11.0766 5.98984L11.4234 6.50977C11.4462 6.54392 11.4754 6.57325 11.5095 6.5961C11.5436 6.61894 11.5818 6.63484 11.6221 6.6429C11.6623 6.65095 11.7037 6.651 11.744 6.64303C11.7842 6.63507 11.8225 6.61925 11.8566 6.59648L11.875 6.58437V8.75H11.25C11.0773 8.75 10.9375 8.88984 10.9375 9.0625V9.6875C10.9375 9.86016 11.0773 10 11.25 10H13.75C13.9227 10 14.0625 9.86016 14.0625 9.6875V9.0625C14.0625 8.88984 13.9227 8.75 13.75 8.75ZM23.75 0H1.25C0.559766 0 0 0.559766 0 1.25V13.75C0 14.4402 0.559766 15 1.25 15H23.75C24.4402 15 25 14.4402 25 13.75V1.25C25 0.559766 24.4402 0 23.75 0ZM1.875 13.125V10.625C3.25586 10.625 4.375 11.7441 4.375 13.125H1.875ZM1.875 4.375V1.875H4.375C4.375 3.25586 3.25586 4.375 1.875 4.375ZM12.5 11.875C10.4289 11.875 8.75 9.91602 8.75 7.5C8.75 5.08359 10.4289 3.125 12.5 3.125C14.5711 3.125 16.25 5.08359 16.25 7.5C16.25 9.9168 14.5703 11.875 12.5 11.875ZM23.125 13.125H20.625C20.625 11.7441 21.7441 10.625 23.125 10.625V13.125ZM23.125 4.375C21.7441 4.375 20.625 3.25586 20.625 1.875H23.125V4.375Z" fill="black"/>
                                </svg>
                                 from 300$</h4>
                        </div> -->
                        <div class="right">
                            <div class="btn">Read More</div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

    </div>
</div>




























































































<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\e122699\resources\views/frontend/pages/service.blade.php ENDPATH**/ ?>