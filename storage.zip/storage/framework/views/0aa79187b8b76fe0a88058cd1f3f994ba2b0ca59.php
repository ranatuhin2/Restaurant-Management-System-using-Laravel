<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="card card-warning">
            <div class="card-header">
                <h3 class="card-title">Edit <b><?php echo e($data['key']); ?></b> Heading</h3>
            </div>
        <?php echo $__env->make('admin.layout.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- /.card-header -->
            <div class="card-body">
                <form action="<?php echo e(route('admin::save_cms')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <input type="hidden" name="key" class="form-control"  value="<?php echo e($data['key']); ?>">
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label>Title</label><span style="color:red;">*</span>
                                <input type="text" name="title" class="form-control" placeholder="Enter ..." value="<?php echo e($data['title']); ?>">
                            </div>
                            <?php if($errors->has('title')): ?>
                                <span class="alert alert-danger"><?php echo e($errors->first('title')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <br>

                    <div class="row">
                        <div class="col-sm-12">

                            <div class="form-group">
                                <label>Description</label>
                                <textarea name="description" class="form-control" rows="5" cols="50" placeholder="Enter ..."><?php echo e($data['description']); ?></textarea>
                            </div>
                            <?php if($errors->has('description')): ?>
                                <span class="alert alert-danger"><?php echo e($errors->first('description')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <!-- input states -->

                    <div class="row">
                        <div class="col-sm-2">
                            <div class="custom-control custom-checkbox">
                                <input name="status" class="custom-control-input custom-control-input-info" type="checkbox" id="customCheckbox4" value="Active" <?php if($data['status'] == "Active"): ?> checked <?php endif; ?> >
                                <label for="customCheckbox4" class="custom-control-label">Status</label>
                            </div>
                            <?php if($errors->has('status')): ?>
                                <span class="alert alert-danger"><?php echo e($errors->first('status')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row">

                        <div class="col-md-12">
                            <div class="form-group" style="text-align:center">
                                <input type="submit" value="Submit" class="btn btn-primary">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!-- /.card-body -->
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\e122699\resources\views/admin/pages/meta_data/edit.blade.php ENDPATH**/ ?>