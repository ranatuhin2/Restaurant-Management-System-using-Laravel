<?php $__env->startSection('content'); ?>
    <!-- banner area  -->
    <section class="banner-area">
        <?php
            $data = \App\Models\Slider::where('status', 1)->get();


        ?>
        <div id="carouselExampleIndicators" class="carousel slide banner-slider" data-ride="carousel">
            <ol class="carousel-indicators">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($loop->index); ?>"
                        class="<?php echo e($loop->first ? 'active' : ''); ?>"></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ol>
            <div class="carousel-inner">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($loop->first): ?>
                        <div class="carousel-item active">
                            <div class="banner-img">
                                <img src="<?php echo e(asset('frontend/assets/image/gallery/' . $values->images)); ?>"
                                    class="zoom-in-zoom-out" class="d-block w-100" alt="" loading="lazy">
                            </div>
                            <div class="carousel-caption">
                                <h1 class="h1"><?php echo e($values->headline); ?></h1>
                                <div class="buy-now">
                                    <a href="#" class="btn1">buy now</a>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="carousel-item">
                            <div class="banner-img">
                                <img src="<?php echo e(asset('frontend/assets/image/gallery/' . $values->images)); ?>"
                                    class="zoom-in-zoom-out" class="d-block w-100" alt="" loading="lazy">
                            </div>
                            <div class="carousel-caption">
                                <h1 class="h1"><?php echo e($values->headline); ?></h1>
                                <div class="buy-now">
                                    <a href="#" class="btn1">buy now</a>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
            <button class="carousel-control-prev" type="button" data-target="#carouselExampleIndicators" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-target="#carouselExampleIndicators" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </button>
        </div>
    </section>
    <!-- banner area end -->

    <!-- about us section  -->
    <section class="about-us">
        <div class="about-left">
            <div class="container">
                <div class="side-heading">
                    <h2 class="h2">about our brand<span></span></h2>
                </div>
                <p class="p1">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam beatae
                    reiciendis consectetur, porro mollitia qui ratione aliquam eius odit eligendi
                    blanditiis voluptatibus at velit, ducimus totam dolor? Saepe, fugit delectus!
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam beatae
                    reiciendis consectetur, porro mollitia qui ratione aliquam eius odit eligendi
                    blanditiis voluptatibus at velit, ducimus totam dolor? Saepe, fugit delectus!
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam beatae
                    reiciendis consectetur, porro mollitia qui ratione aliquam eius odit eligendi
                    blanditiis voluptatibus at velit, ducimus totam dolor? Saepe, fugit delectus!
                </p>
                <div class="buy-now">
                    <a href="about.html" class="btn1">read more</a>
                </div>
            </div>
        </div>
        <div class="about-right-img">
            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-about.webp" alt="" loading="lazy">
        </div>
    </section>
    <!-- about us section end -->

    <!-- featured events section  -->
    <div class="container heading-area">
        <div class="side-heading center-heading">
            <h2 class="h2">featured events<span></span></h2>
        </div>
    </div>
    <section class="fearured-events ">
        <div class="container">
            <div class="owl-carousel owl-theme latest-slider">
                <div class="item member-item">
                    <div class="item-top">
                        <div class="f-image">
                            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-event2.webp" alt=""
                                loading="lazy">
                        </div>
                        <div class=" event-bottom">
                            <div class="left">
                                <ul>
                                    <li>
                                        <div class="h6">event name...</div>
                                    </li>
                                    <li>
                                        <span>Dec 31st, Sat </span>
                                    </li>
                                    <li>
                                        <div class="h7">@Tetto's Farringdon</div>
                                    </li>
                                </ul>
                            </div>
                            <div class="right">
                                <ul>
                                    <li>
                                        <span>$10.00</span>
                                    </li>
                                    <li>
                                        <a href="#" class="btn1">buy now</a>
                                    </li>
                                </ul>
                            </div>

                        </div>
                    </div>

                </div>
                <div class="item member-item">
                    <div class="item-top">
                        <div class="f-image">
                            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-event3.webp" alt=""
                                loading="lazy">
                        </div>
                        <div class=" event-bottom">
                            <div class="left">
                                <ul>
                                    <li>
                                        <div class="h6">event name...</div>
                                    </li>
                                    <li>
                                        <span>Dec 31st, Sat </span>
                                    </li>
                                    <li>
                                        <div class="h7">@Tetto's Farringdon</div>
                                    </li>
                                </ul>
                            </div>
                            <div class="right">
                                <ul>
                                    <li>
                                        <span>$10.00</span>
                                    </li>
                                    <li>
                                        <a href="#" class="btn1">buy now</a>
                                    </li>
                                </ul>
                            </div>

                        </div>
                    </div>

                </div>
                <div class="item member-item">
                    <div class="item-top">
                        <div class="f-image">
                            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-event2.webp" alt=""
                                loading="lazy">
                        </div>
                        <div class=" event-bottom">
                            <div class="left">
                                <ul>
                                    <li>
                                        <div class="h6">event name...</div>
                                    </li>
                                    <li>
                                        <span>Dec 31st, Sat </span>
                                    </li>
                                    <li>
                                        <div class="h7">@Tetto's Farringdon</div>
                                    </li>
                                </ul>
                            </div>
                            <div class="right">
                                <ul>
                                    <li>
                                        <span>$10.00</span>
                                    </li>
                                    <li>
                                        <a href="#" class="btn1">buy now</a>
                                    </li>
                                </ul>
                            </div>

                        </div>
                    </div>

                </div>
                <div class="item member-item">
                    <div class="item-top">
                        <div class="f-image">
                            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-event3.webp" alt=""
                                loading="lazy">
                        </div>
                        <div class=" event-bottom">
                            <div class="left">
                                <ul>
                                    <li>
                                        <div class="h6">event name...</div>
                                    </li>
                                    <li>
                                        <span>Dec 31st, Sat </span>
                                    </li>
                                    <li>
                                        <div class="h7">@Tetto's Farringdon</div>
                                    </li>
                                </ul>
                            </div>
                            <div class="right">
                                <ul>
                                    <li>
                                        <span>$10.00</span>
                                    </li>
                                    <li>
                                        <a href="#" class="btn1">buy now</a>
                                    </li>
                                </ul>
                            </div>

                        </div>
                    </div>

                </div>
                <div class="item member-item">
                    <div class="item-top">
                        <div class="f-image">
                            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-event2.webp" alt=""
                                loading="lazy">
                        </div>
                        <div class=" event-bottom">
                            <div class="left">
                                <ul>
                                    <li>
                                        <div class="h6">event name...</div>
                                    </li>
                                    <li>
                                        <span>Dec 31st, Sat </span>
                                    </li>
                                    <li>
                                        <div class="h7">@Tetto's Farringdon</div>
                                    </li>
                                </ul>
                            </div>
                            <div class="right">
                                <ul>
                                    <li>
                                        <span>$10.00</span>
                                    </li>
                                    <li>
                                        <a href="#" class="btn1">buy now</a>
                                    </li>
                                </ul>
                            </div>

                        </div>
                    </div>

                </div>
                <div class="item member-item">
                    <div class="item-top">
                        <div class="f-image">
                            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-event3.webp" alt=""
                                loading="lazy">
                        </div>
                        <div class=" event-bottom">
                            <div class="left">
                                <ul>
                                    <li>
                                        <div class="h6">event name...</div>
                                    </li>
                                    <li>
                                        <span>Dec 31st, Sat </span>
                                    </li>
                                    <li>
                                        <div class="h7">@Tetto's Farringdon</div>
                                    </li>
                                </ul>
                            </div>
                            <div class="right">
                                <ul>
                                    <li>
                                        <span>$10.00</span>
                                    </li>
                                    <li>
                                        <a href="#" class="btn1">buy now</a>
                                    </li>
                                </ul>
                            </div>

                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <!-- featured events section end -->
    <!-- why choose us  -->
    <section class="choose-us section-area">
        <div class="container">
            <div class="choose-us-in">
                <div class="side-heading center-heading">
                    <h2 class="h2">why choose us<span></span></h2>
                </div>
                <div class="row">
                    <div class="col-lg-4 m-auto">
                        <ul class="top-choose">
                            <li>
                                <div class="h6">reason title</div>
                            </li>
                            <li>
                                <p class="p1">
                                    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Impedit
                                    voluptates illo ad, dicta fugit corporis eveniet atque molestiae.
                                </p>
                            </li>
                            <li><i class="fas fa-music"></i></li>
                        </ul>
                    </div>
                    <div class="col-lg-12">
                        <div class="row align-items-center">
                            <div class="col-lg-4">
                                <ul class="top-choose left-right left-choose">
                                    <li>
                                        <ul>
                                            <li>
                                                <div class="h6">reason title</div>
                                            </li>
                                            <li>
                                                <p>
                                                    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Impedit
                                                    voluptates illo ad, dicta fugit corporis eveniet atque molestiae.
                                                </p>
                                            </li>
                                        </ul>
                                    </li>
                                    <li><i class="fas fa-music"></i></li>
                                </ul>
                            </div>
                            <div class="col-lg-4">
                                <div class="mid-img">
                                    <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-about.webp" alt="logo"
                                        loading="lazy">
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <ul class="top-choose left-right right-choose">
                                    <li>
                                        <ul>
                                            <li>
                                                <div class="h6">reason title</div>
                                            </li>
                                            <li>
                                                <p>
                                                    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Impedit
                                                    voluptates illo ad, dicta fugit corporis eveniet atque molestiae.
                                                </p>
                                            </li>
                                        </ul>
                                    </li>
                                    <li><i class="fas fa-music"></i></li>

                                    <!-- <li><i class="fas fa-music"></i></li>
                                        <li>
                                            <ul>
                                             <li><div class="h6">reason title</div></li>
                                             <li>
                                                 <p>
                                                   Lorem ipsum dolor, sit amet consectetur adipisicing elit. Impedit
                                                   voluptates illo ad, dicta fugit corporis eveniet atque molestiae.
                                                 </p>
                                             </li>
                                            </ul>
                                         </li> -->
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 m-auto">
                        <ul class="top-choose bottom-choose">
                            <li><i class="fas fa-music"></i></li>
                            <li>
                                <div class="h6">reason title</div>
                            </li>
                            <li>
                                <p>
                                    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Impedit
                                    voluptates illo ad, dicta fugit corporis eveniet atque molestiae.
                                </p>
                            </li>
                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!-- why choose us end -->
    <!-- trending events section  -->
    <div class="container heading-area">
        <div class="side-heading center-heading">
            <h2 class="h2">Trending events<span></span></h2>
        </div>
    </div>

    <section class="tranding-events ">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="right-trand-area">
                        <div class="accordion" id="accordionExample">
                            <div class="card">
                                <div class="card-header" id="headingOne">
                                    <button class="btn btn-link btn-block text-left" type="button"
                                        data-toggle="collapse" data-target="#collapseOne" aria-expanded="true"
                                        aria-controls="collapseOne">
                                        <div class="h6">all events <i class="fas fa-chevron-right"></i></div>
                                    </button>
                                </div>

                                <div id="collapseOne" class="collapse show" aria-labelledby="headingOne"
                                    data-parent="#accordionExample">
                                    <div class="card-body">
                                        <div class="cal-area">
                                            <ul class="ul-cal">
                                                <li class="li-cal">
                                                    <ul class="ul-events">
                                                        <li><img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-trand-event.webp"
                                                                alt="" loading="lazy"> </li>
                                                        <li>
                                                            <ul>
                                                                <li><strong>event name...</strong></li>
                                                                <li><span>8:00 pm</span></li>
                                                            </ul>
                                                        </li>
                                                        <li><a href="#" class="btn1">book now</a></li>
                                                    </ul>
                                                </li>
                                                <li class="li-cal">
                                                    <ul class="ul-events">
                                                        <li><img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-trand-event.webp"
                                                                alt="" loading="lazy"> </li>
                                                        <li>
                                                            <ul>
                                                                <li><strong>event name...</strong></li>
                                                                <li><span>8:00 pm</span></li>
                                                            </ul>
                                                        </li>
                                                        <li><a href="#" class="btn1">book now</a></li>
                                                    </ul>
                                                </li>
                                                <li class="li-cal">
                                                    <ul class="ul-events">
                                                        <li><img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-trand-event.webp"
                                                                alt="" loading="lazy"> </li>
                                                        <li>
                                                            <ul>
                                                                <li><strong>event name...</strong></li>
                                                                <li><span>8:00 pm</span></li>
                                                            </ul>
                                                        </li>
                                                        <li><a href="#" class="btn1">book now</a></li>
                                                    </ul>
                                                </li>
                                                <li class="li-cal">
                                                    <ul class="ul-events">
                                                        <li><img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-trand-event.webp"
                                                                alt="" loading="lazy"> </li>
                                                        <li>
                                                            <ul>
                                                                <li><strong>event name...</strong></li>
                                                                <li><span>8:00 pm</span></li>
                                                            </ul>
                                                        </li>
                                                        <li><a href="#" class="btn1">book now</a></li>
                                                    </ul>
                                                </li>
                                                <li class="li-cal">
                                                    <ul class="ul-events">
                                                        <li><img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-trand-event.webp"
                                                                alt="" loading="lazy"> </li>
                                                        <li>
                                                            <ul>
                                                                <li><strong>event name...</strong></li>
                                                                <li><span>8:00 pm</span></li>
                                                            </ul>
                                                        </li>
                                                        <li><a href="#" class="btn1">book now</a></li>
                                                    </ul>
                                                </li>
                                                <li class="li-cal">
                                                    <ul class="ul-events">
                                                        <li><img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-trand-event.webp"
                                                                alt="" loading="lazy"> </li>
                                                        <li>
                                                            <ul>
                                                                <li><strong>event name...</strong></li>
                                                                <li><span>8:00 pm</span></li>
                                                            </ul>
                                                        </li>
                                                        <li><a href="#" class="btn1">book now</a></li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="headingTwo">
                                    <h2 class="mb-0">
                                        <button class="btn btn-link btn-block text-left collapsed" type="button"
                                            data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false"
                                            aria-controls="collapseTwo">
                                            <div class="h6">this saturday <i class="fas fa-chevron-right"></i></div>
                                        </button>
                                    </h2>
                                </div>
                                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo"
                                    data-parent="#accordionExample">
                                    <div class="card-body">
                                        <div class="cal-area">
                                            <ul class="ul-cal">
                                                <li class="li-cal">
                                                    <ul class="ul-events">
                                                        <li><img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-trand-event.webp"
                                                                alt="" loading="lazy"> </li>
                                                        <li>
                                                            <ul>
                                                                <li><strong>event name...</strong></li>
                                                                <li><span>8:00 pm</span></li>
                                                            </ul>
                                                        </li>
                                                        <li><a href="#" class="btn1">book now</a></li>
                                                    </ul>
                                                </li>
                                                <li class="li-cal">
                                                    <ul class="ul-events">
                                                        <li><img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-trand-event.webp"
                                                                alt="" loading="lazy"> </li>
                                                        <li>
                                                            <ul>
                                                                <li><strong>event name...</strong></li>
                                                                <li><span>8:00 pm</span></li>
                                                            </ul>
                                                        </li>
                                                        <li><a href="#" class="btn1">book now</a></li>
                                                    </ul>
                                                </li>
                                                <li class="li-cal">
                                                    <ul class="ul-events">
                                                        <li><img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-trand-event.webp"
                                                                alt="" loading="lazy"> </li>
                                                        <li>
                                                            <ul>
                                                                <li><strong>event name...</strong></li>
                                                                <li><span>8:00 pm</span></li>
                                                            </ul>
                                                        </li>
                                                        <li><a href="#" class="btn1">book now</a></li>
                                                    </ul>
                                                </li>
                                                <li class="li-cal">
                                                    <ul class="ul-events">
                                                        <li><img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-trand-event.webp"
                                                                alt="" loading="lazy"> </li>
                                                        <li>
                                                            <ul>
                                                                <li><strong>event name...</strong></li>
                                                                <li><span>8:00 pm</span></li>
                                                            </ul>
                                                        </li>
                                                        <li><a href="#" class="btn1">book now</a></li>
                                                    </ul>
                                                </li>
                                                <li class="li-cal">
                                                    <ul class="ul-events">
                                                        <li><img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-trand-event.webp"
                                                                alt="" loading="lazy"> </li>
                                                        <li>
                                                            <ul>
                                                                <li><strong>event name...</strong></li>
                                                                <li><span>8:00 pm</span></li>
                                                            </ul>
                                                        </li>
                                                        <li><a href="#" class="btn1">book now</a></li>
                                                    </ul>
                                                </li>
                                                <li class="li-cal">
                                                    <ul class="ul-events">
                                                        <li><img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-trand-event.webp"
                                                                alt="" loading="lazy"> </li>
                                                        <li>
                                                            <ul>
                                                                <li><strong>event name...</strong></li>
                                                                <li><span>8:00 pm</span></li>
                                                            </ul>
                                                        </li>
                                                        <li><a href="#" class="btn1">book now</a></li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="headingThree">
                                    <h2 class="mb-0">
                                        <button class="btn btn-link btn-block text-left collapsed" type="button"
                                            data-toggle="collapse" data-target="#collapseThree" aria-expanded="false"
                                            aria-controls="collapseThree">
                                            <div class="h6">this sunday <i class="fas fa-chevron-right"></i></div>
                                        </button>
                                    </h2>
                                </div>
                                <div id="collapseThree" class="collapse" aria-labelledby="headingThree"
                                    data-parent="#accordionExample">
                                    <div class="card-body">
                                        <div class="cal-area">
                                            <ul class="ul-cal">
                                                <li class="li-cal">
                                                    <ul class="ul-events">
                                                        <li><img src="assets/images/jj-trand-event.webp" alt=""
                                                                loading="lazy"> </li>
                                                        <li>
                                                            <ul>
                                                                <li><strong>event name...</strong></li>
                                                                <li><span>8:00 pm</span></li>
                                                            </ul>
                                                        </li>
                                                        <li><a href="#" class="btn1">book now</a></li>
                                                    </ul>
                                                </li>
                                                <li class="li-cal">
                                                    <ul class="ul-events">
                                                        <li><img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-trand-event.webp"
                                                                alt="" loading="lazy"> </li>
                                                        <li>
                                                            <ul>
                                                                <li><strong>event name...</strong></li>
                                                                <li><span>8:00 pm</span></li>
                                                            </ul>
                                                        </li>
                                                        <li><a href="#" class="btn1">book now</a></li>
                                                    </ul>
                                                </li>
                                                <li class="li-cal">
                                                    <ul class="ul-events">
                                                        <li><img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-trand-event.webp"
                                                                alt="" loading="lazy"> </li>
                                                        <li>
                                                            <ul>
                                                                <li><strong>event name...</strong></li>
                                                                <li><span>8:00 pm</span></li>
                                                            </ul>
                                                        </li>
                                                        <li><a href="#" class="btn1">book now</a></li>
                                                    </ul>
                                                </li>
                                                <li class="li-cal">
                                                    <ul class="ul-events">
                                                        <li><img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-trand-event.webp"
                                                                alt="" loading="lazy"> </li>
                                                        <li>
                                                            <ul>
                                                                <li><strong>event name...</strong></li>
                                                                <li><span>8:00 pm</span></li>
                                                            </ul>
                                                        </li>
                                                        <li><a href="#" class="btn1">book now</a></li>
                                                    </ul>
                                                </li>
                                                <li class="li-cal">
                                                    <ul class="ul-events">
                                                        <li><img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-trand-event.webp"
                                                                alt="" loading="lazy"> </li>
                                                        <li>
                                                            <ul>
                                                                <li><strong>event name...</strong></li>
                                                                <li><span>8:00 pm</span></li>
                                                            </ul>
                                                        </li>
                                                        <li><a href="#" class="btn1">book now</a></li>
                                                    </ul>
                                                </li>
                                                <li class="li-cal">
                                                    <ul class="ul-events">
                                                        <li><img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-trand-event.webp"
                                                                alt="" loading="lazy"> </li>
                                                        <li>
                                                            <ul>
                                                                <li><strong>event name...</strong></li>
                                                                <li><span>8:00 pm</span></li>
                                                            </ul>
                                                        </li>
                                                        <li><a href="#" class="btn1">book now</a></li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <!-- <div class="h6">all events <i class="fas fa-chevron-right"></i></div>
                        <div class="cal-area">
                         <ul class="ul-cal">
                           <li class="li-cal">
                             <ul class="ul-events">
                               <li><strong>event name : </strong><div class="p">Amet minim mollit non</div></li>
                               <li><strong>date: </strong><div class="p">25/12/2002</div></li>
                               <li><strong>time: </strong><div class="p">8:00 pm</div></li>
                               <li><strong>venue:  </strong><div class="p">usa</div></li>
                             </ul>
                           </li>
                           <li class="li-cal">
                             <ul class="ul-events">
                               <li><strong>event name : </strong><div class="p">Amet minim mollit non</div></li>
                               <li><strong>date: </strong><div class="p">25/12/2002</div></li>
                               <li><strong>time: </strong><div class="p">8:00 pm</div></li>
                               <li><strong>venue:  </strong><div class="p">usa</div></li>
                             </ul>
                           </li>
                           <li class="li-cal">
                             <ul class="ul-events">
                               <li><strong>event name : </strong><div class="p">Amet minim mollit non</div></li>
                               <li><strong>date: </strong><div class="p">25/12/2002</div></li>
                               <li><strong>time: </strong><div class="p">8:00 pm</div></li>
                               <li><strong>venue:  </strong><div class="p">usa</div></li>
                             </ul>
                           </li>
                           <li class="li-cal">
                             <ul class="ul-events">
                               <li><strong>event name : </strong><div class="p">Amet minim mollit non</div></li>
                               <li><strong>date: </strong><div class="p">25/12/2002</div></li>
                               <li><strong>time: </strong><div class="p">8:00 pm</div></li>
                               <li><strong>venue:  </strong><div class="p">usa</div></li>
                             </ul>
                           </li>
                           <li class="li-cal">
                             <ul class="ul-events">
                               <li><strong>event name : </strong><div class="p">Amet minim mollit non</div></li>
                               <li><strong>date: </strong><div class="p">25/12/2002</div></li>
                               <li><strong>time: </strong><div class="p">8:00 pm</div></li>
                               <li><strong>venue:  </strong><div class="p">usa</div></li>
                             </ul>
                           </li>
                           <li class="li-cal">
                             <ul class="ul-events">
                               <li><strong>event name : </strong><div class="p">Amet minim mollit non</div></li>
                               <li><strong>date: </strong><div class="p">25/12/2002</div></li>
                               <li><strong>time: </strong><div class="p">8:00 pm</div></li>
                               <li><strong>venue:  </strong><div class="p">usa</div></li>
                             </ul>
                           </li>
                         </ul>
                        </div> -->
                    </div>
                </div>
                <div class="col-md-8">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="home-tab" data-toggle="tab" data-target="#home"
                                type="button" role="tab" aria-controls="home" aria-selected="true">all
                                category</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="profile-tab" data-toggle="tab" data-target="#profile"
                                type="button" role="tab" aria-controls="profile"
                                aria-selected="false">category-1</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="contact-tab" data-toggle="tab" data-target="#contact"
                                type="button" role="tab" aria-controls="contact"
                                aria-selected="false">category-2</button>
                        </li>
                    </ul>
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="home" role="tabpanel"
                            aria-labelledby="home-tab">
                            <div class="owl-carousel owl-theme tranding-slider">
                                <div class="item tranding-items member-item">
                                    <div class="item-top">
                                        <div class="f-image">
                                            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-event2.webp"
                                                alt="" loading="lazy">
                                            <span class="img-top">live music</span>
                                        </div>
                                        <div class="event-bottom">
                                            <div class="left">
                                                <ul>
                                                    <li>
                                                        <div class="h6">event name...</div>
                                                    </li>
                                                    <li>
                                                        <span>Dec 31st, Sat </span>
                                                    </li>
                                                    <li>
                                                        <div class="h7">@Tetto's Farringdon</div>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="right">
                                                <ul>
                                                    <li>
                                                        <span>$10.00</span>
                                                    </li>
                                                    <li>
                                                        <a href="#" class="btn1">buy now</a>
                                                    </li>
                                                </ul>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="gener-area">
                                        <ul class="gener-ul">
                                            <li class="brown border">
                                                gener-1
                                            </li>
                                            <li class="sea-green border">
                                                gener-2
                                            </li>
                                            <li class="gray border">
                                                gener-3
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item tranding-items member-item">
                                    <div class="item-top">
                                        <div class="f-image">
                                            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-event3.webp"
                                                alt="" loading="lazy">
                                            <span class="img-top">comedy</span>
                                        </div>
                                        <div class="event-bottom">
                                            <div class="left">
                                                <ul>
                                                    <li>
                                                        <div class="h6">event name...</div>
                                                    </li>
                                                    <li>
                                                        <span>Dec 31st, Sat </span>
                                                    </li>
                                                    <li>
                                                        <div class="h7">@Tetto's Farringdon</div>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="right">
                                                <ul>
                                                    <li>
                                                        <span>$10.00</span>
                                                    </li>
                                                    <li>
                                                        <a href="#" class="btn1">buy now</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="gener-area">
                                        <ul class="gener-ul">
                                            <li class="orange border">
                                                gener-1
                                            </li>
                                            <li class="purple border">
                                                gener-2
                                            </li>
                                            <li class="blue border">
                                                gener-3
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item tranding-items member-item">
                                    <div class="item-top">
                                        <div class="f-image">
                                            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-event2.webp"
                                                alt="" loading="lazy">
                                            <span class="img-top">meet-ups</span>
                                        </div>
                                        <div class="event-bottom">
                                            <div class="left">
                                                <ul>
                                                    <li>
                                                        <div class="h6">event name...</div>
                                                    </li>
                                                    <li>
                                                        <span>Dec 31st, Sat </span>
                                                    </li>
                                                    <li>
                                                        <div class="h7">@Tetto's Farringdon</div>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="right">
                                                <ul>
                                                    <li>
                                                        <span>$10.00</span>
                                                    </li>
                                                    <li>
                                                        <a href="#" class="btn1">buy now</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="gener-area">
                                        <ul class="gener-ul">
                                            <li class="magenta border">
                                                gener-1
                                            </li>
                                            <li class="black border">
                                                gener-2
                                            </li>
                                            <li class="peach border">
                                                gener-3
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item tranding-items member-item">
                                    <div class="item-top">
                                        <div class="f-image">
                                            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-event3.webp"
                                                alt="" loading="lazy">
                                            <span class="img-top">live music</span>
                                        </div>
                                        <div class=" event-bottom">
                                            <div class="left">
                                                <ul>
                                                    <li>
                                                        <div class="h6">event name...</div>
                                                    </li>
                                                    <li>
                                                        <span>Dec 31st, Sat </span>
                                                    </li>
                                                    <li>
                                                        <div class="h7">@Tetto's Farringdon</div>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="right">
                                                <ul>
                                                    <li>
                                                        <span>$10.00</span>
                                                    </li>
                                                    <li>
                                                        <a href="#" class="btn1">buy now</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="gener-area">
                                        <ul class="gener-ul">
                                            <li class="red border">
                                                gener-1
                                            </li>
                                            <li class="green border">
                                                gener-2
                                            </li>
                                            <li class="sky-blue border">
                                                gener-3
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                            <div class="owl-carousel owl-theme tranding-slider">
                                <div class="item tranding-items">
                                    <div class="item-top">
                                        <div class="f-image">
                                            <span class="img-top">live music</span>
                                            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-event2.webp"
                                                alt="" loading="lazy">
                                        </div>
                                        <div class="event-bottom">
                                            <div class="left">
                                                <ul>
                                                    <li>
                                                        <div class="h6">event name...</div>
                                                    </li>
                                                    <li>
                                                        <span>Dec 31st, Sat </span>
                                                    </li>
                                                    <li>
                                                        <div class="h7">@Tetto's Farringdon</div>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="right">
                                                <ul>
                                                    <li>
                                                        <span>$10.00</span>
                                                    </li>
                                                    <li>
                                                        <a href="#" class="btn1">buy now</a>
                                                    </li>
                                                </ul>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="gener-area">
                                        <ul class="gener-ul">
                                            <li class="brown border">
                                                Genre-1
                                            </li>
                                            <li class="sea-green border">
                                                Genre-2
                                            </li>
                                            <li class="gray border">
                                                Genre-3
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item tranding-items">
                                    <div class="item-top">
                                        <div class="f-image">
                                            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-event3.webp"
                                                alt="" loading="lazy">
                                            <span class="img-top">live music</span>
                                        </div>
                                        <div class=" event-bottom">
                                            <div class="left">
                                                <ul>
                                                    <li>
                                                        <div class="h6">event name...</div>
                                                    </li>
                                                    <li>
                                                        <span>Dec 31st, Sat </span>
                                                    </li>
                                                    <li>
                                                        <div class="h7">@Tetto's Farringdon</div>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="right">
                                                <ul>
                                                    <li>
                                                        <span>$10.00</span>
                                                    </li>
                                                    <li>
                                                        <a href="#" class="btn1">buy now</a>
                                                    </li>
                                                </ul>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="gener-area">
                                        <ul class="gener-ul">
                                            <li class="orange border">
                                                Genre-1
                                            </li>
                                            <li class="purple border">
                                                Genre-2
                                            </li>
                                            <li class="blue border">
                                                Genre-3
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item tranding-items">
                                    <div class="item-top">
                                        <div class="f-image">
                                            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-event2.webp"
                                                alt="" loading="lazy">
                                            <span class="img-top">live music</span>
                                        </div>
                                        <div class=" event-bottom">
                                            <div class="left">
                                                <ul>
                                                    <li>
                                                        <div class="h6">event name...</div>
                                                    </li>
                                                    <li>
                                                        <span>Dec 31st, Sat </span>
                                                    </li>
                                                    <li>
                                                        <div class="h7">@Tetto's Farringdon</div>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="right">
                                                <ul>
                                                    <li>
                                                        <span>$10.00</span>
                                                    </li>
                                                    <li>
                                                        <a href="#" class="btn1">buy now</a>
                                                    </li>
                                                </ul>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="gener-area">
                                        <ul class="gener-ul">
                                            <li class="magenta border">
                                                Genre-1
                                            </li>
                                            <li class="black border">
                                                Genre-2
                                            </li>
                                            <li class="peach border">
                                                Genre-3
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item tranding-items">
                                    <div class="item-top">
                                        <div class="f-image">
                                            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-event3.webp"
                                                alt="" loading="lazy">
                                            <span class="img-top">live music</span>
                                        </div>
                                        <div class=" event-bottom">
                                            <div class="left">
                                                <ul>
                                                    <li>
                                                        <div class="h6">event name...</div>
                                                    </li>
                                                    <li>
                                                        <span>Dec 31st, Sat </span>
                                                    </li>
                                                    <li>
                                                        <div class="h7">@Tetto's Farringdon</div>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="right">
                                                <ul>
                                                    <li>
                                                        <span>$10.00</span>
                                                    </li>
                                                    <li>
                                                        <a href="#" class="btn1">buy now</a>
                                                    </li>
                                                </ul>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="gener-area">
                                        <ul class="gener-ul">
                                            <li class="red border">
                                                Genre-1
                                            </li>
                                            <li class="green border">
                                                Genre-2
                                            </li>
                                            <li class="sky-blue border">
                                                Genre-3
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                            <div class="owl-carousel owl-theme tranding-slider">
                                <div class="item tranding-items">
                                    <div class="item-top">
                                        <div class="f-image">
                                            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-event2.webp"
                                                alt="" loading="lazy">
                                            <span class="img-top">live music</span>
                                        </div>
                                        <div class="event-bottom">
                                            <div class="left">
                                                <ul>
                                                    <li>
                                                        <div class="h6">event name...</div>
                                                    </li>
                                                    <li>
                                                        <span>Dec 31st, Sat </span>
                                                    </li>
                                                    <li>
                                                        <div class="h7">@Tetto's Farringdon</div>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="right">
                                                <ul>
                                                    <li>
                                                        <span>$10.00</span>
                                                    </li>
                                                    <li>
                                                        <a href="#" class="btn1">buy now</a>
                                                    </li>
                                                </ul>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="gener-area">
                                        <ul class="gener-ul">
                                            <li class="brown border">
                                                Genre-1
                                            </li>
                                            <li class="sea-green border">
                                                Genre-2
                                            </li>
                                            <li class="gray border">
                                                Genre-3
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item tranding-items">
                                    <div class="item-top">
                                        <div class="f-image">
                                            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-event3.webp"
                                                alt="" loading="lazy">
                                            <span class="img-top">live music</span>
                                        </div>
                                        <div class="event-bottom">
                                            <div class="left">
                                                <ul>
                                                    <li>
                                                        <div class="h6">event name...</div>
                                                    </li>
                                                    <li>
                                                        <span>Dec 31st, Sat </span>
                                                    </li>
                                                    <li>
                                                        <div class="h7">@Tetto's Farringdon</div>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="right">
                                                <ul>
                                                    <li>
                                                        <span>$10.00</span>
                                                    </li>
                                                    <li>
                                                        <a href="#" class="btn1">buy now</a>
                                                    </li>
                                                </ul>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="gener-area">
                                        <ul class="gener-ul">
                                            <li class="orange border">
                                                Genre-1
                                            </li>
                                            <li class="purple border">
                                                Genre-2
                                            </li>
                                            <li class="blue border">
                                                Genre-3
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item tranding-items">
                                    <div class="item-top">
                                        <div class="f-image">
                                            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-event2.webp"
                                                alt="" loading="lazy">
                                            <span class="img-top">live music</span>
                                        </div>
                                        <div class=" event-bottom">
                                            <div class="left">
                                                <ul>
                                                    <li>
                                                        <div class="h6">event name...</div>
                                                    </li>
                                                    <li>
                                                        <span>Dec 31st, Sat </span>
                                                    </li>
                                                    <li>
                                                        <div class="h7">@Tetto's Farringdon</div>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="right">
                                                <ul>
                                                    <li>
                                                        <span>$10.00</span>
                                                    </li>
                                                    <li>
                                                        <a href="#" class="btn1">buy now</a>
                                                    </li>
                                                </ul>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="gener-area">
                                        <ul class="gener-ul">
                                            <li class="magenta border">
                                                Genre-1
                                            </li>
                                            <li class="black border">
                                                Genre-2
                                            </li>
                                            <li class="peach border">
                                                Genre-3
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item tranding-items">
                                    <div class="item-top">
                                        <div class="f-image">
                                            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-event3.webp"
                                                alt="" loading="lazy">
                                            <span class="img-top">live music</span>
                                        </div>
                                        <div class=" event-bottom">
                                            <div class="left">
                                                <ul>
                                                    <li>
                                                        <div class="h6">event name...</div>
                                                    </li>
                                                    <li>
                                                        <span>Dec 31st, Sat </span>
                                                    </li>
                                                    <li>
                                                        <div class="h7">@Tetto's Farringdon</div>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="right">
                                                <ul>
                                                    <li>
                                                        <span>$10.00</span>
                                                    </li>
                                                    <li>
                                                        <a href="#" class="btn1">buy now</a>
                                                    </li>
                                                </ul>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="gener-area">
                                        <ul class="gener-ul">
                                            <li class="red border">
                                                Genre-1
                                            </li>
                                            <li class="green border">
                                                Genre-2
                                            </li>
                                            <li class="sky-blue border">
                                                Genre-3
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="view-all">
                        <a href="all-events.html">view all <i class="fas fa-long-arrow-alt-right"></i></a>
                    </div>
                </div>

            </div>

        </div>
    </section>
    <!-- tranding events section end -->

    <!-- newsletter section  -->
    <section class="newsletter section-area">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="n-letter-txt">
                        <div class="h4">Lorem ipsum dolor sit amet consectetur adipisicing elit.</div>
                        <form class="my-form">
                            <div class="form-group">
                                <input class="form-control" type="email" placeholder="Enter your e-mail" />
                            </div>
                            <button type="submit" class="btn1 btn2">subscribe</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- newsletter section end -->

    <!-- latest news section  -->

    <section class="latest-news">
        <div class="container">
            <div class="side-heading center-heading">
                <h2 class="h2">Latest News<span></span></h2>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <div class="p-category">
                        <div class="product-bottom">
                            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-latestnews-1.webp" alt="logo"
                                loading="lazy">
                        </div>
                        <div class="product-top">
                            <div class="h5">news title..</div>
                            <span>November 16, 2016 by admin</span>
                            <p class="p2">
                                AAmet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint. Velit
                                officia consequat duis enim velit mollit. Exercitation veniam consequat sunt
                                nostrud amet.
                            </p>
                            <a href="news-details.html" class="btn1">read more</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="p-category">
                        <div class="product-bottom">
                            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-latestnews-2.webp" alt="logo"
                                loading="lazy">
                        </div>
                        <div class="product-top">
                            <div class="h5">news title..</div>
                            <span>November 16, 2016 by admin</span>
                            <p class="p2">
                                Pesticides analysis, residual solvents, heavy metals, mycotoxins analysis,
                                terpene profiling, moisture content and microbial testing are what
                                Sci-Chem Texas Labs use to deliver a total cannabis safety profile.
                            </p>
                            <a href="news-details.html" class="btn1">read more</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="p-category">
                        <div class="product-bottom">
                            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-latestnews-3.webp" alt="logo"
                                loading="lazy">
                        </div>
                        <div class="product-top">
                            <div class="h5">news title..</div>
                            <span>November 16, 2016 by admin</span>
                            <p class="p2">
                                Sci-Chem Texas Labs uses Innovative development and validation methods for
                                the qualitative and quantitative determination of major cannabinoids and
                                cannabis plant material.
                            </p>
                            <a href="news-details.html" class="btn1">read more</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="view-all">
                <a href="<?php echo e(route('all_news')); ?>">view all <i class="fas fa-long-arrow-alt-right"></i></a>
            </div>
        </div>
    </section>
    <!-- latest news section end -->

    <!-- contact us form -->
    <section class="contact-us section-area">
        <div class="container">
            <div class="footer-form contact-us-form">
                <div class="contact">
                    <div class="h3">
                        <span class="blackberry">send us a message</span>
                    </div>
                </div>
                <form class="my-form">
                    <div class="form-group">
                        <input type="text" class="form-control" id="exampleFormControlInput4"
                            placeholder="Email Id" />
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" id="exampleFormControlInput1"
                            placeholder="Full Name" />
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" id="exampleFormControlInput10"
                            placeholder="subject" />
                    </div>
                    <div class="form-group">
                        <textarea class="form-control" id="exampleFormControlTextarea1" rows="4" placeholder="Your message..."></textarea>
                    </div>
                    <div class="contact-btn">
                        <button type="submit" class="btn1">submit</button>
                    </div>
                </form>

            </div>
        </div>
    </section>
    <!-- contact us form end -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            console.log("helloHome")
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\122687\resources\views/frontend/pages/index.blade.php ENDPATH**/ ?>