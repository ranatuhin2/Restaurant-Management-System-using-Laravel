<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="card card-warning">
            <div class="card-header">
                <h3 class="card-title"> Add Testimonial</h3>
            </div>
            <?php if(session()->has('success')): ?>
                <div class="alert alert-success">
                    <button id="bannerClose" class="btn border-0 p-0"></button>
                    <?php echo e(session()->get('success')); ?>


                </div>
        <?php endif; ?>
        <!-- /.card-header -->
            <div class="card-body">
                <form action="<?php echo e(route('admin::save_testimonial')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="exampleInputFile">File input</label>
                                <span style="color:red;">*</span>
                                <div class="input-group">
                                    <div class="custom-file">
                                        <input type="file" class="custom-file-input" name="image" id="exampleInputFile">
                                        <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                                    </div>
                                    <div class="input-group-append">
                                        <span class="input-group-text">Upload</span>
                                    </div>
                                </div>
                            </div>

                            <?php if($errors->has('image')): ?>
                                <span class="alert alert-danger"><?php echo e($errors->first('image')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <br>

                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Name</label>
                                <span style="color:red;">*</span>
                                <input type="text" name="name" class="form-control" placeholder="Enter ...">
                            </div>
                            <?php if($errors->has('name')): ?>
                                <span class="alert alert-danger"><?php echo e($errors->first('name')); ?></span>
                            <?php endif; ?>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Occupation</label>
                                <span style="color:red;">*</span>
                                <input type="text" name="occupation" class="form-control" placeholder="Enter ...">
                            </div>
                            <?php if($errors->has('occupation')): ?>
                                <span class="alert alert-danger"><?php echo e($errors->first('occupation')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <br>

                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label>Message</label>
                                <span style="color:red;">*</span>
                                <textarea name="message" class="form-control" rows="6" cols="50" placeholder="Enter ..."></textarea>
                            </div>
                            <?php if($errors->has('message')): ?>
                                <span class="alert alert-danger"><?php echo e($errors->first('message')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
            <!-- input states -->

            <div class="row">

                <div class="col-md-12">
                    <div class="form-group" style="text-align:center">
                        <input type="submit" value="Submit" class="btn btn-primary">
                    </div>
                </div>
            </div>
            </form>
            </div>
        </div>
        <!-- /.card-body -->
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\e122699\resources\views/admin/pages/testimonial/add.blade.php ENDPATH**/ ?>