
<?php $__env->startSection('content'); ?>
<div class="card">
              <div class="card-header">
                <h3 class="card-title">Contacts DataTables</h3>
              </div>
            <?php if(session('message')): ?>
            <?php echo e(session('message')); ?>

            <?php endif; ?>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                  <thead class="table-success">
                  <tr>
                        <th>Sl. No</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Subject</th>
                        <th>Message</th>
                        <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php if(isset($data)): ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($info->id); ?></td>
                        <td><?php echo e($info->name); ?></td>
                        <td><?php echo e($info->email); ?></td>
                        <td><?php echo e($info->subject); ?></td>
                        <td><?php echo e($info->message); ?></td>
                        <td>
                        <big>

                        <a href="<?php echo e(route('admin::delete-contact',['id'=>$info['id']])); ?>"><i onclick="return confirm('Do you want to delete this ?')" style="color:red;" class="fa fa-trash" aria-hidden="true"></i></a>
                        </td>
                        </big>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                  </tbody>
                  <tfoot class="table-success" >
                  <tr>
                       
                        <th>Sl. No</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Subject</th>
                        <th>Message</th>
                        <th>Action</th>
                  </tr>
                  </tfoot>
                </table>
              </div>
              <!-- /.card-body -->
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\adminTempLaravel8\adminTempLaravel8\resources\views/admin/pages/contact/index.blade.php ENDPATH**/ ?>