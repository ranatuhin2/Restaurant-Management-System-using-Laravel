
<?php $__env->startSection('content'); ?>
    <div class="container">
    <div class="text-center mb-4">
         <h3>Add Team  </h3>
         <p class="text-muted">Complete the form below to Add</p>
      </div>
        <?php if(session('message')): ?>
        <?php echo e(session('message')); ?>

        <?php endif; ?>
        <div class="container d-flex justify-content-center">
        <form action="<?php echo e(route('admin::save-team')); ?>" method="post" enctype="multipart/form-data" style="width:50vw; min-width:300px;" >
        <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="form-label">Name</label>
                <input type="text" class="form-control"  name="name" placeholder="Name" >
            </div>
            <div class="form-group">
                <label class="form-label">Designation</label>
                <input type="text" class="form-control"  name="designation" placeholder="Designation" >
            </div>
            <div class="form-group">
                <label class="form-label">Image</label>
                <input type="file"  class="form-control" name="image" required >
            </div>
            
            <div class="from-group">
                <button class="btn btn-sm btn-primary" >Submit</button>
            </div>
        </form>
</div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\adminTempLaravel8\adminTempLaravel8\resources\views/admin/pages/ourteam/add.blade.php ENDPATH**/ ?>