<link href="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap-switch-button@1.1.0/css/bootstrap-switch-button.min.css" rel="stylesheet">


<?php $__env->startSection('content'); ?>
    <div class="content-wrapper" style="min-height: 357px;">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Contact Info</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin::dashboard')); ?>">Dashboard</a> </li>
                            <li class="breadcrumb-item active">Contact Info</li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->
<?php echo $__env->make('admin.layout.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <span class="card-title alert alert-danger"><i class="fa fa-exclamation"></i>&nbsp; only one will show in website. which one is active.
                                    &nbsp;
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </span>




                            </div>
                            <!-- /.card-header -->
                            <div class="card-body">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                    <tr>
                                        <th>Sl.No.</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Address</th>
                                        <th>Website</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php if(!empty($allContact)): ?>
                                        <?php $i=0; ?>
                                        <?php $__currentLoopData = $allContact; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $i++; ?>
                                            <tr>
                                                <td><?php echo e($i); ?></td>
                                                <td>
                                                    <?php echo e($data['email']); ?>

                                                </td>
                                                <td>
                                                    <?php if(!empty($data['phone_code'])): ?>
                                                    (<?php echo e($data['phone_code']); ?>)<?php echo e(substr($data['phone'],0,4)); ?> <?php echo e(substr($data['phone'],5,strlen($data['phone']))); ?>

                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php echo e(substr($data['address'],0,25)); ?>

                                                    <?php if(strlen($data['address']) > 25): ?>...<?php endif; ?>

                                                </td>
                                                <td>
                                                    <?php echo e($data['website']); ?>

                                                </td>
                                                <td>
                                                    <span id="status<?php echo e($data->id); ?>">
                                                    <?php if($data->status == 'Active'): ?>
                                                    <a href="javascript:active_inactive_banner('<?php echo $data->id; ?>','<?php echo $data->status; ?>');" class="btn btn-success btn-sm"><span class="fa fa-check"></span> </a>&emsp;
                                                    <?php else: ?>
                                                    <a href="javascript:active_inactive_banner('<?php echo $data->id; ?>','<?php echo $data->status; ?>');" class="btn btn-warning btn-sm" ><span class="fa fa-ban"></span> </a>&emsp;
                                                    <?php endif; ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <a href="<?php echo e(route('admin::edit_contact',['id'=>$data['id']])); ?>" class="btn btn-warning btn-sm"><i class="fa fa-edit"></i> </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    </tbody>
                                    <tfoot>
                                    <tr>
                                        <th>Sl.No.</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Address</th>
                                        <th>Website</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
    var Inactive='Inactive';
    var Active='Active';
    function active_inactive_banner(id,status) {
        $.ajax({
            type: "post",
            url: '<?php echo e(route('admin::status_contact')); ?>',
            data: {
                _token: '<?php echo csrf_token();?>',
                id: id,
                status: status
            },
            success: function (data) {
                var resp = JSON.parse(data);
                $('#status' + resp.id).html(resp.html);
                $(document).find('.child #status' + resp.id).html(resp.html);
                toastr.success('Status is '+resp.status)
            }
        });
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\e122699\resources\views/admin/pages/contact_info/index.blade.php ENDPATH**/ ?>