<footer class="footer">
    <div class="container">
        <?php
                    $data = \App\Models\FooterDescription::latest()->first();


                ?>
        <div class="row">
            <div class="col-lg-4 col-md-6">
                <div class="f-logo-area">
                    <a class="navbar-brand" href="#">
                        <h2>LOGO</h2>
                    </a>
                    <p class="p2">
                        <?php echo e($data->description); ?>

                    </p>
                </div>
                <div class="contact-area">
                    <div class="contact icon-area">
                        <div  class="h3">
                            <span class="blackberry">follow us</span>
                        </div>
                    </div>
                    <ul class=" icon-area">
                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="contact-area">
                    <div class="contact">
                        <div  class="h3">
                            <span class="blackberry">important links</span>
                        </div>
                    </div>
                    <ul class="other-links">
                        <li><a href="<?php echo e(route('index')); ?>">home</a></li>
                        <li><a href="<?php echo e(route('about_us')); ?>">about us</a></li>
                        <li><a href="<?php echo e(route('comedy')); ?>">comedy</a></li>
                        <li><a href="<?php echo e(route('clubbing')); ?>">clubbing</a></li>
                        <li><a href="<?php echo e(route('live_music')); ?>">live-music</a></li>
                        <li><a href="<?php echo e(route('all_news')); ?>">news</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="contact-area">
                    <div class="contact">
                        <div class="h3">
                            <span class="blackberry">contacts</span>
                        </div>
                    </div>
                    <ul class="email-ph">
                        <li><a href="#">abcdef@gmail.com</a></li>
                        <li><a href="#">000 000 0000</a></li>
                    </ul>
                </div>
                <div class="contact-area">
                    <div class="contact">
                        <div  class="h3">
                            <span class="blackberry">quick links</span>
                        </div>
                    </div>
                    <ul class="other-links">
                        <li><a href="<?php echo e(route('terms')); ?>">Terms of use</a></li>
                        <li><a href="<?php echo e(route('policy')); ?>">Privacy policy</a></li>
                        <li><a href="<?php echo e(route('faq')); ?>">FAQ</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="copyrightarea">
            <p class="p2 mb-0">
                ©copyrights. All rights are resarved.
            </p>
        </div>
    </div>
</footer>
<a id="back-to-top" href="#" class="btn-light btn-lg back-to-top" role="button"><i class="fas fa-arrow-up"></i></a>
<?php /**PATH C:\xampp\htdocs\122687\resources\views/frontend/layout/footer.blade.php ENDPATH**/ ?>