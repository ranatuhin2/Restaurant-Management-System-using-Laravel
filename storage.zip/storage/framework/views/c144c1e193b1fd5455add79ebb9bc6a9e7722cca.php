<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="card card-warning">
            <div class="card-header">
                <h3 class="card-title"> Add About</h3>
            </div>
            <?php if(session()->has('success')): ?>
                <div class="alert alert-success">
                    <button id="bannerClose" class="btn border-0 p-0"></button>
                    <?php echo e(session()->get('success')); ?>

                </div>
        <?php endif; ?>
        <!-- /.card-header -->
            <div class="card-body">
                <form action="<?php echo e(route('admin::update_about',$data['id'])); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Preview Image</label>
                                <img src="<?php echo e(asset($data['image'])); ?>" alt="No Picture Found" style="width: auto;height: 200px;object-fit: cover;">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="exampleInputFile">File input</label>
                                <div class="input-group">
                                    <div class="custom-file">
                                        <input type="file" class="custom-file-input" name="image" id="exampleInputFile">
                                        <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                                    </div>
                                    <div class="input-group-append">
                                        <span class="input-group-text">Upload</span>
                                    </div>
                                </div>
                            </div>

                            <?php if($errors->has('image')): ?>
                                <span class="alert alert-danger"><?php echo e($errors->first('image')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <br>

                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label>Title</label><span style="color:red;">*</span>
                                <input type="text" name="title" class="form-control" placeholder="Enter ..." value="<?php echo e($data['title']); ?>">
                            </div>
                            <?php if($errors->has('title')): ?>
                                <span class="alert alert-danger"><?php echo e($errors->first('title')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <br>

                    <div class="row">
                        <div class="col-sm-12">

                            <div class="form-group">
                                <label>Description</label><span style="color:red;">*</span>
                                <textarea name="description" class="summernote"  placeholder="Enter ..."><?php echo e($data['description']); ?></textarea>
                            </div>
                            <?php if($errors->has('description')): ?>
                                <span class="alert alert-danger"><?php echo e($errors->first('description')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <!-- input states -->

                    <div class="row">

                        <div class="col-md-12">
                            <div class="form-group" style="text-align:center">
                                <input type="submit" value="Submit" class="btn btn-primary">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!-- /.card-body -->
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\e122699\resources\views/admin/pages/about_page/edit.blade.php ENDPATH**/ ?>