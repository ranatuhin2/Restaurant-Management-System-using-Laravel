
<?php $__env->startSection('content'); ?>

<div class="container">
            <div class="text-center mb-4">
         <h3>Edit Entry</h3>
         <p class="text-muted">Complete the form below to update</p>
      </div>

      <div class="container d-flex justify-content-center">
         <form action="<?php echo e(route('admin::update_about')); ?>" method="post" style="width:50vw; min-width:300px;">
         <?php echo csrf_field(); ?>
         <div class="form-group" >
            <input type="hidden" name="id" value="<?php echo e($about['id']); ?>">
         </div>
               <div class="form-group">
                  <label class="form-label">Title</label>
                  <input type="text" required class="form-control" value="<?php echo e($about['title']); ?>" name="title" placeholder="Title">
               </div>
               <div class="form-group">
                  <label class="form-label">Description</label>
                  <input type="text" required class="form-control" value="<?php echo e($about['description']); ?>" name="description" placeholder="Description">
               </div>
           

            
                  <div class="form-group">
                  <label class="form-label">Experience</label>
                  <input type="text" required class="form-control" value="<?php echo e($about['exp']); ?>" name="exp"  placeholder="Experience">
               </div>
               <div class="form-group">
                  <label class="form-label">Chef</label>
                  <input type="text" required class="form-control" value="<?php echo e($about['chef']); ?>" name="chef" placeholder="Chef">
               </div>
            

            

            <div>
               <button type="submit"  class="btn btn-success" name="submit">Submit</button>
            </div>
         </form>
      </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\adminTempLaravel8\adminTempLaravel8\resources\views/admin/pages/about/edit.blade.php ENDPATH**/ ?>