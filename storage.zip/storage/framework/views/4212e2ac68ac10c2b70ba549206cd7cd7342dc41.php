<?php if(Session::has('success')): ?>
    <div class="alert alert-success" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <i class="mdi mdi-account-check"></i>
        <strong><?php echo e(Session::get('success')); ?></strong>
    </div>
<?php endif; ?>
<?php if(Session::has('password_success')): ?>
    <div class="alert alert-success" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <i class="mdi mdi-account-check"></i>
        <strong><?php echo e(Session::get('password_success')); ?></strong>
    </div>
<?php endif; ?>
<?php if(Session::has('error')): ?>
    <div class="alert alert-danger profile" style="font-size: 17px;">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <strong><?php echo e(Session::get('error')); ?></strong>
    </div>
<?php endif; ?>
<?php if(Session::has('password_error')): ?>
    <div class="alert alert-danger profile" style="font-size: 17px;">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <strong><?php echo e(Session::get('password_error')); ?></strong>
    </div>
<?php endif; ?>
<?php if(Session::has('warning')): ?>
    <div class="alert alert-warning profile" style="font-size: 17px;">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <strong><?php echo e(Session::get('warning')); ?></strong>
    </div>
<?php endif; ?>
<?php if(Session::has('info')): ?>
    <div class="alert alert-info profile" style="font-size: 17px;">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <strong><?php echo e(Session::get('info')); ?></strong>
    </div>
<?php endif; ?>
<?php if(Session::has('primary')): ?>
    <div class="alert alert-primary profile" style="font-size: 17px;">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <strong><?php echo e(Session::get('primary')); ?></strong>
    </div>
<?php endif; ?>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php if(Session::has('success_two')): ?>
    <div class="alert alert-success profile">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h5><?php echo e(Session::get('success_two')); ?></h5>
    </div>
<?php endif; ?>
<?php /**PATH F:\xampp\htdocs\adminTempLara8\resources\views/messages.blade.php ENDPATH**/ ?>