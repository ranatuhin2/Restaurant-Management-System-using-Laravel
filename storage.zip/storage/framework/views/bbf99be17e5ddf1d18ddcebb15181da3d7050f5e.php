<title>JJbox.uk - ABOUT-US</title>
<?php $__env->startSection('content'); ?>
    <?php
        $data = \App\Models\AboutUs::latest()->first();

    ?>
<!--inner-banner-->
<section id="banner" class="inner-backg">
    <div class="inner-pg-banner">
        <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-inner-banner.webp" alt="inner-banner" loading="lazy">
        <div class="inner-ban-head">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page"><i class="fal fa-chevron-right"></i><a>about us</a></li>
                </ol>
            </nav>
        </div>
    </div>
</section>
<!--inner-banner-end-->

<!-- auout section  -->
<section class="about-us">
    <div class="about-left">
        <div class="container">
            <div class="side-heading">
              <h2 class="h2"><?php echo e($data->heading); ?><span></span></h2>
            </div>
            <p class="p1">
                <?php echo $data->description; ?>

            </p>








        </div>
    </div>
    <div class="about-right-img">
        <img src="<?php echo e(url('/')); ?>/frontend/assets/images/<?php echo e($data->image); ?>" alt="" loading="lazy">
    </div>
</section>
<!-- auout section end -->

<!-- our team section  -->
<section class="our-team section-area">
    <div class="container">
        <div class="side-heading center-heading">
            <h2 class="h2">meet our team<span></span></h2>
        </div>
        <div class="owl-carousel owl-theme team-slider">
            <div class="item">
                <div class="member-1">
                    <div class="member-img">
                        <img src="<?php echo e(url('/')); ?>/frontend/assets/images/member.webp" alt="" loading="lazy">
                    </div>
                    <div class="member-txt">
                        <div class="h5">Jane Cooper</div>
                        <ul>
                            <li><a href="#"><i class="fab fa-facebook-f fb"></i></a></li>
                            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="member-1">
                    <div class="member-img">
                        <img src="<?php echo e(url('/')); ?>/frontend/assets/images/member-1.webp" alt="" loading="lazy">
                    </div>
                    <div class="member-txt">
                        <div class="h5">Jane Cooper</div>
                        <ul>
                            <li><a href="#"><i class="fab fa-facebook-f fb"></i></a></li>
                            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="member-1">
                    <div class="member-img">
                        <img src="<?php echo e(url('/')); ?>/frontend/assets/images/member-2.webp" alt="" loading="lazy">
                    </div>
                    <div class="member-txt">
                        <div class="h5">Jane Cooper</div>
                        <ul>
                            <li><a href="#"><i class="fab fa-facebook-f fb"></i></a></li>
                            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="member-1">
                    <div class="member-img">
                        <img src="<?php echo e(url('/')); ?>/frontend/assets/images/member-3.webp" alt="" loading="lazy">
                    </div>
                    <div class="member-txt">
                        <div class="h5">Jane Cooper</div>
                        <ul>
                            <li><a href="#"><i class="fab fa-facebook-f fb"></i></a></li>
                            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="member-1">
                    <div class="member-img">
                        <img src="<?php echo e(url('/')); ?>/frontend/assets/images/member.webp" alt="" loading="lazy">
                    </div>
                    <div class="member-txt">
                        <div class="h5">Jane Cooper</div>
                        <ul>
                            <li><a href="#"><i class="fab fa-facebook-f fb"></i></a></li>
                            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="member-1">
                    <div class="member-img">
                        <img src="<?php echo e(url('/')); ?>/frontend/assets/images/member-1.webp" alt="" loading="lazy">
                    </div>
                    <div class="member-txt">
                        <div class="h5">Jane Cooper</div>
                        <ul>
                            <li><a href="#"><i class="fab fa-facebook-f fb"></i></a></li>
                            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="member-1">
                    <div class="member-img">
                        <img src="<?php echo e(url('/')); ?>/frontend/assets/images/member-2.webp" alt="" loading="lazy">
                    </div>
                    <div class="member-txt">
                        <div class="h5">Jane Cooper</div>
                        <ul>
                            <li><a href="#"><i class="fab fa-facebook-f fb"></i></a></li>
                            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
    </div>


    </div>
</section>
<!-- our team section end -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            console.log("helloAbout")
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\122687\resources\views/frontend/pages/about_us.blade.php ENDPATH**/ ?>