<section class="top-bar">
    <div class="container">
    <div class="row">
        <div class="col-lg-8 col-5 col-md-7">
            <div class="left-area">
            <ul class="left-area-info">
                <li>
                    <i class="fab fa-facebook-f"></i>
                </li>
                <li>
                    <i class="fab fa-twitter"></i>
                </li>
                <li>
                    <i class="fab fa-instagram"></i>
                </li>
            </ul>
            </div>
        </div>
        <div class="col-lg-4 col-7 col-md-5">
            <div class="right-area">
            <ul>
                <li class="sign">
                  <a href="#">sign up</a>
                </li>
                <li class="log">
                    <a href="#">log in</a>
                  </li>
            </ul>
            </div>
        </div>
    </div>
    </div>
</section>


<header>
  <div class="nav_area" id="sticklynavbar">
    <div class="container">
        <nav class="navbar navbar-expand-lg">
            <a class="navbar-brand order-1" href="index.html">
                LOGO
            </a>
            <button class="navbar-toggler order-2" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <i class="fas fa-bars"></i>
            </button>

            <div class="collapse navbar-collapse order-4 order-lg-3" id="navbarSupportedContent">
              <ul class="navbar-nav">
                <li class="nav-item ">
                  <a class="nav-link
<?php echo e(Request::routeIs('index') ? 'active' : ''); ?>

" href="<?php echo e(route('index')); ?>">Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item
<?php echo e(Request::routeIs('about_us') ? 'active' : ''); ?>

">
                  <a class="nav-link" href="<?php echo e(route('about_us')); ?>">About us</a>
                </li>
                <li class="nav-item
<?php echo e(Request::routeIs('all_events') ? 'active' : ''); ?>

">
                  <a class="nav-link" href="<?php echo e(route('all_events')); ?>">all events</a>
                </li>
                <li class="nav-item
<?php echo e(Request::routeIs('all_news') ? 'active' : ''); ?>

">
                    <a class="nav-link" href="<?php echo e(route('all_news')); ?>">News</a>
                </li>
                <li class="nav-item
<?php echo e(Request::routeIs('clubbing') ? 'active' : ''); ?>


">
                  <a class="nav-link" href="<?php echo e(route('clubbing')); ?>">Clubbing</a>
                </li>
                <li class="nav-item
<?php echo e(Request::routeIs('comedy') ? 'active' : ''); ?>


">
                  <a class="nav-link" href="<?php echo e(route('comedy')); ?>">Comedy</a>
                </li>
                <li class="nav-item
<?php echo e(Request::routeIs('live_music') ? 'active' : ''); ?>

">
                    <a class="nav-link" href="<?php echo e(route('live_music')); ?>">live music</a>
                </li>
                <li class="nav-item
<?php echo e(Request::routeIs('contact') ? 'active' : ''); ?>

">
                  <a class="nav-link" href="<?php echo e(route('contact')); ?>">contact us</a>
              </li>
              </ul>
            </div>
            <button class="search-btn my-lg-0 order-2 order-lg-4" onclick="myFunction()"><i class="fas fa-search"></i></button>
        </nav>
        <div class="srcSection" id="myDIV" style="display: none;">
          <form class="my-form">
           <div class="form-group mb-0">
            <input class="form-control " id="srch" type="text" placeholder="What are you searching for?">
           </div>
          </form>
      </div>
    </div>
</div>
</header>
<?php /**PATH C:\xampp\htdocs\122687\resources\views/frontend/layout/header.blade.php ENDPATH**/ ?>