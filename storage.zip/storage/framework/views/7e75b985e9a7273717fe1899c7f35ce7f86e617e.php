<?php $__env->startSection('content'); ?>

<!--inner-banner-->
<section id="banner" class="inner-backg">
    <div class="inner-pg-banner">
        <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-inner-banner.webp" alt="inner-banner" loading="lazy">
        <div class="inner-ban-head">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('index')); ?>">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page"><i class="fal fa-chevron-right"></i><a>privacy policy</a></li>
                </ol>
            </nav>
        </div>
    </div>
</section>
<!--inner-banner-end-->

<!--member's support page-->
<section class="privacy-policy common-sec section-area">
    <section class="container">
        <section class="privacy-text">
            <div class="h3"> How We Collect and Use Information</div>
            <h6>This privacy notice discloses the privacy practices for getsavvydigital.com. This privacy notice applies solely to information collected by this website. It will notify you of the following:</h6>
            <ul class="about-ul">
                <li>
                    <p class="p1">
                        What personally identifiable information is collected from you through the website, how it is used and with whom it may be shared.
                    </p>
                </li>
                <li>
                    <p class="p1">
                        What choices are available to you regarding the use of your data?
                    </p>
                </li>
                <li>
                    <p class="p1">
                        The security procedures in place to protect the misuse of your information.
                    </p>
                </li>
                <li>
                    <p class="p1">
                        How you can correct any inaccuracies in the information.
                    </p>
                </li>
            </ul>
            <div class="h3"> Information Collection, Use, and Sharing</div>
            <ul class="about-ul">
                <li>
                    <p class="p1">
                        We are the sole owners of the information collected on this site. We only have access to/collect information that you voluntarily give us via email or other direct contact from you. We will not sell or rent this information to anyone.
                    </p>
                </li>
                <li>
                    <p class="p1">
                        We will use your information to respond to you, regarding the reason you contacted us. We will not share your information with any third party outside of our organization, other than as necessary to fulfill your request, e.g. to ship an order.
                    </p>
                </li>
                <li>
                    <p class="p1">
                        Unless you ask us not to, we may contact you via email in the future to tell you about specials, new products or services, or changes to this privacy policy.
                    </p>
                </li>
            </ul>
            <div class="h3"> Your Access to and Control Over Information</div>
            <h6>
                You may opt out of any future contacts from us at any time. You can do the following at any time by contacting us via the email address or phone number given on our website:
            </h6>
            <ul class="about-ul">
                <li>
                    <p class="p1">
                        See what data we have about you if any.
                    </p>
                </li>
                <li>
                    <p class="p1">
                        Change/correct any data we have about you.
                    </p>
                </li>
                <li>
                    <p class="p1">
                        Have us delete any data we have about you.
                    </p>
                </li>
                <li>
                    <p class="p1">
                        Express any concern you have about our use of your data.
                    </p>
                </li>
            </ul>
            <div class="h3"> Cookies</div>
            <ul class="about-ul">
                <li>
                    <p class="p1">
                       We use “cookies” on this site. A cookie is a piece of data stored on a
                       site visitor's hard drive to help us improve your access to our site and
                       identify repeat visitors to our site. For instance, when we use a cookie
                       to identify you, you would not have to enter a password more than once,
                       thereby saving time while on our site. Cookies can also enable us to
                       track and target the interests of our users to enhance the experience on
                       our site. Usage of a cookie is in no way linked to any personally
                       identifiable information on our site.
                    </p>
                </li>
            </ul>
            <div class="h3"> Security</div>
            <ul class="about-ul">
                <li>
                    <p class="p1">
                        We take precautions to protect your information. When you submit sensitive information via the website, your information is protected both online and offline.
                    </p>
                </li>
                <li>
                    <p class="p1">
                        If you believe that we are not abiding by this privacy policy, please contact us immediately via email : <strong>abcdef@gmail.com</strong>.
                    </p>
                </li>
            </ul>
        </section>
    </section>
</section>
<!--member's support page end-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\122687\resources\views/frontend/pages/policy.blade.php ENDPATH**/ ?>