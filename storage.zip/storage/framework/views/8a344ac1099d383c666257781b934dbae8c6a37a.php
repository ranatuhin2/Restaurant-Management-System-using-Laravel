<?php $__env->startSection('content'); ?>
    <div class="content-wrapper" style="min-height: 357px;">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Site Information</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin::dashboard')); ?>">Dashboard</a> </li>
                            <li class="breadcrumb-item "><a href="<?php echo e(route('admin::information')); ?>">Site Information</a></li>
                            <li class="breadcrumb-item active"><?php if(empty($siteInfo)): ?> Add <?php else: ?> Edit <?php endif; ?></li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <?php echo $__env->make('messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <!-- general form elements -->
                        <div class="card card-primary">
                            <div class="card-header">
                                <h3 class="card-title"><?php if(empty($siteInfo)): ?> Add <?php else: ?> Edit <?php endif; ?></h3>
                            </div>
                            <form action="<?php echo e(route('admin::information_save')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="id" value="<?php echo e($siteInfo['id']); ?>">
                                <div class="card-body">
                                    <?php if(!empty($siteInfo) && $siteInfo['is_image'] == 'Yes'): ?>
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Preview Image</label>
                                            <img src="<?php echo e($siteInfo['value']); ?>" style="width: 120px;height: 50px;">
                                        </div>
                                    <?php endif; ?>
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Key</label>
                                        <input type="text" class="form-control" name="key" id="exampleInputEmail1" placeholder="Enter Key" value="<?php echo e($siteInfo['key']); ?>" <?php if(!empty($siteInfo)): ?> readonly <?php endif; ?>>
                                    </div>
                                    <?php if(empty($siteInfo)): ?>
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Is Image</label>
                                        <div class="custom-control custom-radio">
                                            <input class="custom-control-input" type="radio" id="customRadio1" name="customRadio" value="Yes" onclick="showHide('Yes')">
                                            <label for="customRadio1" class="custom-control-label">Yes</label>
                                        </div>
                                        <div class="custom-control custom-radio">
                                            <input class="custom-control-input" type="radio" id="customRadio2" name="customRadio" value="No" checked onclick="showHide('No')">
                                            <label for="customRadio2" class="custom-control-label">No</label>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    <?php if(!empty($siteInfo) && $siteInfo['is_image'] == 'No'): ?>
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Value</label>
                                            <input type="text" class="form-control" name="value" id="exampleInputEmail1" <?php if(!empty($siteInfo) && $siteInfo['is_image'] == 'No'): ?> value="<?php echo e($siteInfo['value']); ?>" <?php endif; ?> placeholder="Enter Value">
                                        </div>
                                    <?php elseif(!empty($siteInfo) && $siteInfo['is_image'] == 'Yes'): ?>
                                        <div class="form-group">
                                            <label for="exampleInputFile">Image</label>
                                            <div class="input-group">
                                                <div class="custom-file">
                                                    <input type="file" class="custom-file-input" name="image" id="exampleInputFile">
                                                    <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                                                </div>
                                                <div class="input-group-append">
                                                    <span class="input-group-text">Upload</span>
                                                </div>
                                            </div>
                                        </div>
                                    <?php else: ?>
                                        <div class="form-group" id="value_div">
                                            <label for="exampleInputEmail1">Value</label>
                                            <input type="text" class="form-control" name="value" id="exampleInputEmail1" placeholder="Enter Value">
                                        </div>
                                        <div class="form-group" id="image_div" style="display: none">
                                            <label for="exampleInputFile">Image</label>
                                            <div class="input-group">
                                                <div class="custom-file">
                                                    <input type="file" class="custom-file-input" name="image" id="exampleInputFile">
                                                    <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                                                </div>
                                                <div class="input-group-append">
                                                    <span class="input-group-text">Upload</span>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <!-- /.card-body -->

                                <div class="card-footer">
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
    </div>
    <?php $__env->startPush('scripts'); ?>
        <script>
            /*** Image Value Start ***/
            showHide = (value) => {
                if (value == 'Yes'){
                    document.getElementById('image_div').style.display = 'block';
                    document.getElementById('value_div').style.display = 'none';
                }else {
                    document.getElementById('image_div').style.display = 'none';
                    document.getElementById('value_div').style.display = 'block';
                }
            }
            /*** Image Value End ***/
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\e122699\resources\views/admin/pages/site_info/add.blade.php ENDPATH**/ ?>