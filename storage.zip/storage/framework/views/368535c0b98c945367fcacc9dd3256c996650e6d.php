<?php $__env->startSection('content'); ?>
    <!--inner-banner-->
    <section id="banner" class="inner-backg">
        <div class="inner-pg-banner">
            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-inner-banner.webp" alt="inner-banner" loading="lazy">
            <div class="inner-ban-head">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('index')); ?>">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page"><i
                                class="fal fa-chevron-right"></i><a>Comedy</a></li>
                    </ol>
                </nav>
            </div>
        </div>
    </section>
    <!--inner-banner-end-->


    <!-- all events page  -->
    <section class="tranding-events section-area">
        <div class="container">
            <div class="row">
                <div class="col-md-5 col-lg-4">
                    <div class="search-for">
                        <div class="h6">search for</div>
                        <form class="my-form ">
                            <select class="selectpicker" data-show-subtext="true" data-live-search="true">
                                <option>event</option>
                                <option>event 1</option>
                                <option>event 2</option>
                                <option>event 3</option>
                                <option>event 4</option>
                                <option>event 5</option>
                                <option>event 6</option>
                                <option>event 7</option>
                                <option>event 8</option>
                            </select>
                        </form>
                    </div>
                    <div class="calender">
                        <ul class="cal-top">
                            <li class="h6">when?</li>
                            <li><a href="#">see all</a></li>
                        </ul>
                        <div class="top-area">
                            <div class="arrows">
                                <div class="arrow1">
                                    <a href="#"><i class="fas fa-chevron-left"></i></a>
                                </div>
                                <div class="arrow1">
                                    <a href="#"><i class="fas fa-chevron-right"></i></a>
                                </div>
                            </div>
                            <div class="date">
                                <div class="h3">may</div>
                                <div class="h6 mb-0">2023</div>
                            </div>
                        </div>
                        <ul class="weekdays">
                            <li>su</li>
                            <li>mo</li>
                            <li>tu</li>
                            <li>we</li>
                            <li>th</li>
                            <li>fr</li>
                            <li>sa</li>
                        </ul>
                        <ul class="days">
                            <li>1</li>
                            <li>2</li>
                            <li>3</li>
                            <li>4</li>
                            <li>5</li>
                            <li>6</li>
                            <li>7</li>
                            <li>8</li>
                            <li>9</li>
                            <li><span class="active">10</span></li>
                            <li>11</li>
                            <li>12</li>
                            <li>13</li>
                            <li>14</li>
                            <li>15</li>
                            <li>16</li>
                            <li>17</li>
                            <li>18</li>
                            <li>19</li>
                            <li>20</li>
                            <li>21</li>
                            <li>22</li>
                            <li>23</li>
                            <li>24</li>
                            <li>25</li>
                            <li>26</li>
                            <li>27</li>
                            <li>28</li>
                            <li>29</li>
                            <li>30</li>
                            <li>31</li>
                        </ul>
                    </div>
                    <div class="search-for">
                        <div class="h6">where?</div>
                        <form class="my-form">
                            <select class="selectpicker" data-show-subtext="true" data-live-search="true">
                                <option>location</option>
                                <option>location 1</option>
                                <option>location 2</option>
                                <option>location 3</option>
                                <option>location 4</option>
                                <option>location 5</option>
                                <option>location 6</option>
                                <option>location 7</option>
                                <option>location 8</option>
                            </select>
                        </form>
                    </div>
                    <div class="category-area">
                        <ul class="cal-top">
                            <li class="h6">what?</li>
                            <li><a href="#">clear filter</a></li>
                        </ul>
                        <div class="accordion" id="accordionExample">
                            <div class="card">
                                <div class="card-header" id="headingOne">
                                    <h2 class="mb-0">
                                        <button class="btn btn-link btn-block text-left" type="button"
                                                data-toggle="collapse" data-target="#collapseOne" aria-expanded="true"
                                                aria-controls="collapseOne">
                                            category <i class="fas fa-angle-right"></i>
                                        </button>
                                    </h2>
                                </div>

                                <div id="collapseOne" class="collapse show" aria-labelledby="headingOne"
                                     data-parent="#accordionExample">
                                    <div class="card-body">
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="checkbox" id="inlineCheckbox1"
                                                   value="option1">
                                            <label class="form-check-label" for="inlineCheckbox1">Clubbing</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="checkbox" id="inlineCheckbox2"
                                                   value="option2">
                                            <label class="form-check-label" for="inlineCheckbox2">Comedy</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="checkbox" id="inlineCheckbox3"
                                                   value="option3">
                                            <label class="form-check-label" for="inlineCheckbox3">Culture</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="checkbox" id="inlineCheckbox4"
                                                   value="option4">
                                            <label class="form-check-label" for="inlineCheckbox4">Live Music</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="checkbox" id="inlineCheckbox5"
                                                   value="option5">
                                            <label class="form-check-label" for="inlineCheckbox5">Meet-ups</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="headingTwo">
                                    <h2 class="mb-0">
                                        <button class="btn btn-link btn-block text-left collapsed" type="button"
                                                data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false"
                                                aria-controls="collapseTwo">
                                            genre <i class="fas fa-angle-right"></i>
                                        </button>
                                    </h2>
                                </div>
                                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo"
                                     data-parent="#accordionExample">
                                    <div class="card-body">
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="checkbox" id="inlineCheckbox6"
                                                   value="option6">
                                            <label class="form-check-label" for="inlineCheckbox6">genre-1</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="checkbox" id="inlineCheckbox7"
                                                   value="option7">
                                            <label class="form-check-label" for="inlineCheckbox7">genre-2</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="checkbox" id="inlineCheckbox8"
                                                   value="option8">
                                            <label class="form-check-label" for="inlineCheckbox8">genre-3</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="checkbox" id="inlineCheckbox9"
                                                   value="option9">
                                            <label class="form-check-label" for="inlineCheckbox9">genre-4</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="checkbox" id="inlineCheckbox10"
                                                   value="option10">
                                            <label class="form-check-label" for="inlineCheckbox10">genre-5</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>




                </div>
                <div class="col-md-7 col-lg-8">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="home-tab" data-toggle="tab" data-target="#home"
                                    type="button" role="tab" aria-controls="home" aria-selected="true">all
                                category</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="profile-tab" data-toggle="tab" data-target="#profile"
                                    type="button" role="tab" aria-controls="profile"
                                    aria-selected="false">category-1</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="contact-tab" data-toggle="tab" data-target="#contact"
                                    type="button" role="tab" aria-controls="contact"
                                    aria-selected="false">category-2</button>
                        </li>
                    </ul>
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="home" role="tabpanel"
                             aria-labelledby="home-tab">
                            <div class="owl-carousel owl-theme tranding-slider">
                                <div class="item tranding-items member-item">
                                    <div class="item-top">
                                        <div class="f-image">
                                            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-event2.webp"
                                                 alt="" loading="lazy">
                                            <span class="img-top">live music</span>
                                        </div>
                                        <div class="event-bottom">
                                            <div class="left">
                                                <ul>
                                                    <li>
                                                        <div class="h6">event name...</div>
                                                    </li>
                                                    <li>
                                                        <span>Dec 31st, Sat </span>
                                                    </li>
                                                    <li>
                                                        <div class="h7">@Tetto's Farringdon</div>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="right">
                                                <ul>
                                                    <li>
                                                        <span>$10.00</span>
                                                    </li>
                                                    <li>
                                                        <a href="#" class="btn1">buy now</a>
                                                    </li>
                                                </ul>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="gener-area">
                                        <ul class="gener-ul">
                                            <li class="brown border">
                                                gener-1
                                            </li>
                                            <li class="sea-green border">
                                                gener-2
                                            </li>
                                            <li class="gray border">
                                                gener-3
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item tranding-items member-item">
                                    <div class="item-top">
                                        <div class="f-image">
                                            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-event3.webp"
                                                 alt="" loading="lazy">
                                            <span class="img-top">comedy</span>
                                        </div>
                                        <div class="event-bottom">
                                            <div class="left">
                                                <ul>
                                                    <li>
                                                        <div class="h6">event name...</div>
                                                    </li>
                                                    <li>
                                                        <span>Dec 31st, Sat </span>
                                                    </li>
                                                    <li>
                                                        <div class="h7">@Tetto's Farringdon</div>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="right">
                                                <ul>
                                                    <li>
                                                        <span>$10.00</span>
                                                    </li>
                                                    <li>
                                                        <a href="#" class="btn1">buy now</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="gener-area">
                                        <ul class="gener-ul">
                                            <li class="orange border">
                                                gener-1
                                            </li>
                                            <li class="purple border">
                                                gener-2
                                            </li>
                                            <li class="blue border">
                                                gener-3
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item tranding-items member-item">
                                    <div class="item-top">
                                        <div class="f-image">
                                            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-event2.webp"
                                                 alt="" loading="lazy">
                                            <span class="img-top">meet-ups</span>
                                        </div>
                                        <div class="event-bottom">
                                            <div class="left">
                                                <ul>
                                                    <li>
                                                        <div class="h6">event name...</div>
                                                    </li>
                                                    <li>
                                                        <span>Dec 31st, Sat </span>
                                                    </li>
                                                    <li>
                                                        <div class="h7">@Tetto's Farringdon</div>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="right">
                                                <ul>
                                                    <li>
                                                        <span>$10.00</span>
                                                    </li>
                                                    <li>
                                                        <a href="#" class="btn1">buy now</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="gener-area">
                                        <ul class="gener-ul">
                                            <li class="magenta border">
                                                gener-1
                                            </li>
                                            <li class="black border">
                                                gener-2
                                            </li>
                                            <li class="peach border">
                                                gener-3
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item tranding-items member-item">
                                    <div class="item-top">
                                        <div class="f-image">
                                            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-event3.webp"
                                                 alt="" loading="lazy">
                                            <span class="img-top">live music</span>
                                        </div>
                                        <div class=" event-bottom">
                                            <div class="left">
                                                <ul>
                                                    <li>
                                                        <div class="h6">event name...</div>
                                                    </li>
                                                    <li>
                                                        <span>Dec 31st, Sat </span>
                                                    </li>
                                                    <li>
                                                        <div class="h7">@Tetto's Farringdon</div>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="right">
                                                <ul>
                                                    <li>
                                                        <span>$10.00</span>
                                                    </li>
                                                    <li>
                                                        <a href="#" class="btn1">buy now</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="gener-area">
                                        <ul class="gener-ul">
                                            <li class="red border">
                                                gener-1
                                            </li>
                                            <li class="green border">
                                                gener-2
                                            </li>
                                            <li class="sky-blue border">
                                                gener-3
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                            <div class="owl-carousel owl-theme tranding-slider">
                                <div class="item tranding-items">
                                    <div class="item-top">
                                        <div class="f-image">
                                            <span class="img-top">live music</span>
                                            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-event2.webp"
                                                 alt="" loading="lazy">
                                        </div>
                                        <div class="event-bottom">
                                            <div class="left">
                                                <ul>
                                                    <li>
                                                        <div class="h6">event name...</div>
                                                    </li>
                                                    <li>
                                                        <span>Dec 31st, Sat </span>
                                                    </li>
                                                    <li>
                                                        <div class="h7">@Tetto's Farringdon</div>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="right">
                                                <ul>
                                                    <li>
                                                        <span>$10.00</span>
                                                    </li>
                                                    <li>
                                                        <a href="#" class="btn1">buy now</a>
                                                    </li>
                                                </ul>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="gener-area">
                                        <ul class="gener-ul">
                                            <li class="brown border">
                                                gener-1
                                            </li>
                                            <li class="sea-green border">
                                                gener-2
                                            </li>
                                            <li class="gray border">
                                                gener-3
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item tranding-items">
                                    <div class="item-top">
                                        <div class="f-image">
                                            <img src="assets/images/jj-event3.webp" alt="" loading="lazy">
                                            <span class="img-top">live music</span>
                                        </div>
                                        <div class=" event-bottom">
                                            <div class="left">
                                                <ul>
                                                    <li>
                                                        <div class="h6">event name...</div>
                                                    </li>
                                                    <li>
                                                        <span>Dec 31st, Sat </span>
                                                    </li>
                                                    <li>
                                                        <div class="h7">@Tetto's Farringdon</div>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="right">
                                                <ul>
                                                    <li>
                                                        <span>$10.00</span>
                                                    </li>
                                                    <li>
                                                        <a href="#" class="btn1">buy now</a>
                                                    </li>
                                                </ul>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="gener-area">
                                        <ul class="gener-ul">
                                            <li class="orange border">
                                                gener-1
                                            </li>
                                            <li class="purple border">
                                                gener-2
                                            </li>
                                            <li class="blue border">
                                                gener-3
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item tranding-items">
                                    <div class="item-top">
                                        <div class="f-image">
                                            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-event2.webp"
                                                 alt="" loading="lazy">
                                            <span class="img-top">live music</span>
                                        </div>
                                        <div class=" event-bottom">
                                            <div class="left">
                                                <ul>
                                                    <li>
                                                        <div class="h6">event name...</div>
                                                    </li>
                                                    <li>
                                                        <span>Dec 31st, Sat </span>
                                                    </li>
                                                    <li>
                                                        <div class="h7">@Tetto's Farringdon</div>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="right">
                                                <ul>
                                                    <li>
                                                        <span>$10.00</span>
                                                    </li>
                                                    <li>
                                                        <a href="#" class="btn1">buy now</a>
                                                    </li>
                                                </ul>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="gener-area">
                                        <ul class="gener-ul">
                                            <li class="magenta border">
                                                gener-1
                                            </li>
                                            <li class="black border">
                                                gener-2
                                            </li>
                                            <li class="peach border">
                                                gener-3
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item tranding-items">
                                    <div class="item-top">
                                        <div class="f-image">
                                            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-event3.webp"
                                                 alt="" loading="lazy">
                                            <span class="img-top">live music</span>
                                        </div>
                                        <div class=" event-bottom">
                                            <div class="left">
                                                <ul>
                                                    <li>
                                                        <div class="h6">event name...</div>
                                                    </li>
                                                    <li>
                                                        <span>Dec 31st, Sat </span>
                                                    </li>
                                                    <li>
                                                        <div class="h7">@Tetto's Farringdon</div>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="right">
                                                <ul>
                                                    <li>
                                                        <span>$10.00</span>
                                                    </li>
                                                    <li>
                                                        <a href="#" class="btn1">buy now</a>
                                                    </li>
                                                </ul>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="gener-area">
                                        <ul class="gener-ul">
                                            <li class="red border">
                                                gener-1
                                            </li>
                                            <li class="green border">
                                                gener-2
                                            </li>
                                            <li class="sky-blue border">
                                                gener-3
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                            <div class="owl-carousel owl-theme tranding-slider">
                                <div class="item tranding-items">
                                    <div class="item-top">
                                        <div class="f-image">
                                            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-event2.webp"
                                                 alt="" loading="lazy">
                                            <span class="img-top">live music</span>
                                        </div>
                                        <div class="event-bottom">
                                            <div class="left">
                                                <ul>
                                                    <li>
                                                        <div class="h6">event name...</div>
                                                    </li>
                                                    <li>
                                                        <span>Dec 31st, Sat </span>
                                                    </li>
                                                    <li>
                                                        <div class="h7">@Tetto's Farringdon</div>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="right">
                                                <ul>
                                                    <li>
                                                        <span>$10.00</span>
                                                    </li>
                                                    <li>
                                                        <a href="#" class="btn1">buy now</a>
                                                    </li>
                                                </ul>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="gener-area">
                                        <ul class="gener-ul">
                                            <li class="brown border">
                                                gener-1
                                            </li>
                                            <li class="sea-green border">
                                                gener-2
                                            </li>
                                            <li class="gray border">
                                                gener-3
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item tranding-items">
                                    <div class="item-top">
                                        <div class="f-image">
                                            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-event3.webp"
                                                 alt="" loading="lazy">
                                            <span class="img-top">live music</span>
                                        </div>
                                        <div class="event-bottom">
                                            <div class="left">
                                                <ul>
                                                    <li>
                                                        <div class="h6">event name...</div>
                                                    </li>
                                                    <li>
                                                        <span>Dec 31st, Sat </span>
                                                    </li>
                                                    <li>
                                                        <div class="h7">@Tetto's Farringdon</div>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="right">
                                                <ul>
                                                    <li>
                                                        <span>$10.00</span>
                                                    </li>
                                                    <li>
                                                        <a href="#" class="btn1">buy now</a>
                                                    </li>
                                                </ul>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="gener-area">
                                        <ul class="gener-ul">
                                            <li class="orange border">
                                                gener-1
                                            </li>
                                            <li class="purple border">
                                                gener-2
                                            </li>
                                            <li class="blue border">
                                                gener-3
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item tranding-items">
                                    <div class="item-top">
                                        <div class="f-image">
                                            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-event2.webp"
                                                 alt="" loading="lazy">
                                            <span class="img-top">live music</span>
                                        </div>
                                        <div class=" event-bottom">
                                            <div class="left">
                                                <ul>
                                                    <li>
                                                        <div class="h6">event name...</div>
                                                    </li>
                                                    <li>
                                                        <span>Dec 31st, Sat </span>
                                                    </li>
                                                    <li>
                                                        <div class="h7">@Tetto's Farringdon</div>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="right">
                                                <ul>
                                                    <li>
                                                        <span>$10.00</span>
                                                    </li>
                                                    <li>
                                                        <a href="#" class="btn1">buy now</a>
                                                    </li>
                                                </ul>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="gener-area">
                                        <ul class="gener-ul">
                                            <li class="magenta border">
                                                gener-1
                                            </li>
                                            <li class="black border">
                                                gener-2
                                            </li>
                                            <li class="peach border">
                                                gener-3
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item tranding-items">
                                    <div class="item-top">
                                        <div class="f-image">
                                            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-event3.webp"
                                                 alt="" loading="lazy">
                                            <span class="img-top">live music</span>
                                        </div>
                                        <div class=" event-bottom">
                                            <div class="left">
                                                <ul>
                                                    <li>
                                                        <div class="h6">event name...</div>
                                                    </li>
                                                    <li>
                                                        <span>Dec 31st, Sat </span>
                                                    </li>
                                                    <li>
                                                        <div class="h7">@Tetto's Farringdon</div>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="right">
                                                <ul>
                                                    <li>
                                                        <span>$10.00</span>
                                                    </li>
                                                    <li>
                                                        <a href="#" class="btn1">buy now</a>
                                                    </li>
                                                </ul>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="gener-area">
                                        <ul class="gener-ul">
                                            <li class="red border">
                                                gener-1
                                            </li>
                                            <li class="green border">
                                                gener-2
                                            </li>
                                            <li class="sky-blue border">
                                                gener-3
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- all events page end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\122687\resources\views/frontend/pages/comedy.blade.php ENDPATH**/ ?>