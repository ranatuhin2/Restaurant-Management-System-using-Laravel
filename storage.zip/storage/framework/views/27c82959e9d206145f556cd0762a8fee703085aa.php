<?php $__env->startSection('content'); ?>
    
    <style>
        #cover-spin {
            position: fixed;
            width: 100%;
            left: 0;
            right: 0;
            top: 0;
            bottom: 0;
            background-color: rgba(45, 45, 45, 0.7);
            z-index: 9999;
            display: none;
        }

        @-webkit-keyframes spin {
            from {
                -webkit-transform: rotate(0deg);
            }

            to {
                -webkit-transform: rotate(360deg);
            }
        }

        @keyframes spin {
            from {
                transform: rotate(0deg);
            }

            to {
                transform: rotate(360deg);
            }
        }

        #cover-spin::after {
            content: '';
            display: block;
            position: absolute;
            left: 48%;
            top: 40%;
            width: 40px;
            height: 40px;
            border-style: solid;
            border-color: #bcefde;
            border-top-color: transparent;
            border-width: 4px;
            border-radius: 50%;
            -webkit-animation: spin .8s linear infinite;
            animation: spin .8s linear infinite;
        }
    </style>
    
    <!--inner-banner-->
    <section id="banner" class="inner-backg">
        <div class="inner-pg-banner">
            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-inner-banner.webp" alt="inner-banner" loading="lazy">
            <div class="inner-ban-head">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page"><i
                                class="fal fa-chevron-right"></i><a>contact us</a></li>
                    </ol>
                </nav>
            </div>
        </div>
    </section>
    <!--inner-banner-end-->

    <!-- contact us page  -->
    <section class="contact-us section-area">
        <div class="container">
            <div class="footer-form contact-us-form">
                <div class="contact">

                    <div id="cover-spin"></div>

                    <div class="h3">
                        <span class="blackberry">send us a message</span>
                    </div>
                </div>
                <form class="my-form" action="<?php echo e(route('contact.post')); ?>" method="POST" id="contact_form"
                    autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <input type="text" class="form-control" name="email" id="email" placeholder="Email Id" />
                        <span class="text-danger error-text email_error"></span>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" name="name" id="name" placeholder="Full Name" />
                        <span class="text-danger error-text name_error"></span>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" id="subject" name="subject" placeholder="subject" />
                        <span class="text-danger error-text subject_error"></span>
                    </div>
                    <div class="form-group">
                        <textarea class="form-control" name="message" id="message" rows="4" placeholder="Your message..."></textarea>
                        <span class="text-danger error-text message_error"></span>
                    </div>
                    <div class="contact-btn">
                        <button type="submit" class="btn1">submit</button>
                    </div>
                </form>

            </div>
            <?php
                $address=\App\Models\ContactDetail::where('key','address')->where('status',1)->get();
              $phone=\App\Models\ContactDetail::where('key','phone')->where('status',1)->get();
               $email=\App\Models\ContactDetail::where('key','email')->where('status',1)->get();
            ?>
            <div class="get-in-touch">
                <div class="row">
                    <div class="col-md-4">
                        <div class="get-in">
                            <div class="contact-icon">
                                <i class="fas fa-globe-americas"></i>
                            </div>
                            <ul>
                                <?php $__currentLoopData = $address; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
<?php echo e($value->value); ?>                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="get-in">
                            <div class="contact-icon">
                                <i class="fas fa-phone-alt"></i>
                            </div>
                            <ul>
                                <?php $__currentLoopData = $phone; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="#"><?php echo e($value->value); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="get-in">
                            <div class="contact-icon">
                                <i class="fas fa-envelope-open-text"></i>
                            </div>
                            <ul>
                                <?php $__currentLoopData = $email; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="#"><?php echo e($value->value); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- contact us page end -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

    <script type="text/javascript">


     $('#cover-spin').hide()
     $(function() {


         $('#contact_form').on('submit', function(e) {

             e.preventDefault();
             $('#cover-spin').show()
             $.ajax({
                 url: $(this).attr('action'),
                 method: $(this).attr('method'),
                 data: new FormData(this),
                 processData: false,
                 dataType: 'json',
                 contentType: false,
                 beforeSend: function() {
                     $(document).find('span.error-text').text('');
                 },
                 success: function(data) {
                     if (data.status == 0) {
                        $('#cover-spin').hide()
                         $.each(data.error, function(key, value) {
                             $('span.' + key + '_error').text(value[0]);
                         });
                    } else {
                         $('#contact_form')[0].reset();
                        $('#cover-spin').hide()
                         // alert(data.success);
                       // toastr.success(data.success);
                         Swal.fire(
                             {
                                 position: 'top-end',
                                 icon: 'success',
                                 title: 'Successfully sent your request',
                                 showConfirmButton: false,
                                 timer: 1500
                             }

                         )
                     }
                 }
             });

         });
     });
    </script>
    <?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\122687\resources\views/frontend/pages/contact.blade.php ENDPATH**/ ?>