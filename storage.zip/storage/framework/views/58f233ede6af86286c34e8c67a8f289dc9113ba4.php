<?php $__env->startSection('content'); ?>

<!--inner-banner-->
<section id="banner" class="inner-backg">
    <div class="inner-pg-banner">
        <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-inner-banner.webp" alt="inner-banner" loading="lazy">
        <div class="inner-ban-head">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('index')); ?>">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page"><i class="fal fa-chevron-right"></i><a>terms of use</a></li>
                </ol>
            </nav>
        </div>
    </div>
</section>
<!--inner-banner-end-->

<!-- terms & conditions page  -->
<section class="conditions common-sec section-area">
    <div class="container">
        <div class="top-box">
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi eaque, vel amet culpa fuga
            corporis dolorem facere totam repellendus nisi hic accusamus ducimus? Hic neque iste
            molestiae sed reiciendis illo!
        </p>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi eaque, vel amet culpa fuga
            corporis dolorem facere totam repellendus nisi hic accusamus ducimus? Hic neque iste
            molestiae sed reiciendis illo!
        </p>
        </div>
        <?php

    $data = \App\Models\Terms::where('status',1)->get();
    ?>
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


        <div class="h3"><?php echo e($value->heading); ?></div>
        <p class="p1">
         <?php echo $value->description; ?>

        </p>
        <p class="p1">
            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Labore et odit quo soluta fuga
            possimus maxime perferendis totam aliquam saepe repudiandae ad sit qui architecto dolorem
            rem eligendi, libero natus? Lorem, ipsum dolor sit amet consectetur adipisicing elit.
        </p>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    </section>
    <!-- terms & conditions page end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\122687\resources\views/frontend/pages/terms.blade.php ENDPATH**/ ?>