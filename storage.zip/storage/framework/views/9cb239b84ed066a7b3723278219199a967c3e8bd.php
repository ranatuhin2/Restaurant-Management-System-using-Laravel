<?php $__env->startSection('content'); ?>
    <div class="inner-banner">
        <img src="<?php echo e(url('/')); ?>/frontend/assets/images/product.webp" alt="">
        <div class="banner-content">
            <h3>Our Story And Team</h3>
            <ol class="breadcrumb">


                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a>

                </li>





                <li class="breadcrumb-item active" aria-current="page">About Us</li>


            </ol>
        </div>
    </div>

    <div class="about-us gap">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="image">
                        <img src="<?php echo e(asset($about['image'] ?? '')); ?>" alt="" loading="lazy" loading="lazy">
                    </div>
                </div>
                <div class="col-lg-6">

                    <div class="text">
                        <?php
                        if (!empty($about['title'])) {
                            $about_title_key = strpos($about['title'], ' ');
                            $about_first = substr($about['title'], 0, $about_title_key);
                            $about_end = substr($about['title'], $about_title_key, strlen($about['title']));
                        ?>
                        <h2><?php echo e($about_first); ?> <span><?php echo e($about_end); ?></span></h2>
                        <?php } ?>
                        <p><?php echo $about['description'] ?? ''; ?></p>
                    </div>
                </div>
            </div>
            <div class="row align-items-center">
                <div class="col-lg-6 order">
                    <div class="text">
                        <?php
                        if (!empty($process['title'])) {
                            $process_title_key = strpos($process['title'], ' ');
                            $process_first = substr($process['title'], 0, $process_title_key);
                            $process_end = substr($process['title'], $process_title_key, strlen($process['title']));
                            ?>
                        <h2><?php echo e($process_first); ?> <span><?php echo e($process_end); ?></span></h2>
                        <?php } ?>
                        <p><?php echo $process['description'] ?? ''; ?></p>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="image">
                        <img src="<?php echo e(asset($process['image'] ?? '')); ?>" alt="" loading="lazy" loading="lazy">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php
    $team_heading = \App\Models\Cms::where('key','our_team')
        ->where('status','Active')->select('title','description')->first();
    if(!empty($team_heading)) {
        $explode4 = explode(' ', $team_heading['title']);
        if (count($explode4) > 1) {
            $team_title1 = $explode4[0];
            unset($explode4[0]);
            $team_title2 = implode(' ', $explode4);
        }else{
            $team_title1 = implode(' ', $explode4);
            $team_title2 = ' ';
        }
    }

    ?>
    <div class="team section gap">
        <div class="container">
            <?php if(!empty($team_heading)): ?>
                <div class="head">
                    <!-- <p class="tag">Our Classes</p> -->
                    <h2><?php echo e($team_title1 ?? ""); ?> <span><?php echo e($team_title2 ?? ""); ?></span></h2>
                    <p class="description"><?php echo e($team_heading['description'] ?? ""); ?></p>
                </div>
            <?php endif; ?>
            <div class="owl-carousel owl-theme team">
                <?php $__currentLoopData = $all_team_members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item">
                    <div class="image"><img src="<?php echo e(asset($member['profile_photo'])); ?>" alt=""></div>
                    <div class="text">
                        <h3><?php echo e($member['name']); ?></h3>
                        <span><?php echo e($member['occupation']); ?></span>
                        <p><?php echo e(Str::limit($member['description'],135)); ?></p>
                        <div class="social-links">
                            <?php if(!empty($member['facebook'])): ?>
                            <a class="facebook" href="<?php echo e($member['facebook'] ?? ""); ?>"><i class="fab fa-facebook-f"></i></a>
                            <?php endif; ?>
                            <?php if(!empty($member['twitter'])): ?>
                            <a class="twitter" href="<?php echo e($member['twitter'] ?? ""); ?>"><i class="fab fa-twitter"></i></a>
                            <?php endif; ?>
                            <?php if(!empty($member['linkedin'])): ?>
                            <a class="linkedin" href="<?php echo e($member['linkedin'] ?? ""); ?>"><i class="fab fa-linkedin-in"></i></a>
                            <?php endif; ?>
                            <?php if(!empty($member['youtube'])): ?>
                            <a class="youtube" href="<?php echo e($member['youtube'] ?? ""); ?>"><i class="fab fa-youtube"></i></a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\e122699\resources\views/frontend/pages/about.blade.php ENDPATH**/ ?>