<?php
    $info = \App\Helper\admin\siteInformation::siteInfo();
    $segment = Request::segment(1);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo e($info['site_name'] ?? ""); ?>

        <?php if(!in_array($segment,['product-details'])): ?> | <?php echo e(Route::currentRouteName()); ?> <?php else: ?>  | details  <?php endif; ?>
    </title>
    <link rel="shortcut icon" href="<?php echo e($info['fav_icon'] ?? ''); ?>" type="image/x-icon">
    <link rel="icon" href="<?php echo e($info['fav_icon'] ?? ''); ?>" type="image/x-icon">
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/frontend/library/style/app.css">
    <link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&display=swap" rel="stylesheet">
    <!-- Toastr -->
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/admin/plugins/toastr/toastr.min.css">
</head>
<body>

<header>
<?php echo $__env->make('frontend.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</header>

<?php echo $__env->yieldContent('content'); ?>

<footer class="footer">
   <?php echo $__env->make('frontend.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</footer>
<!-- Toastr -->

<!-- jQuery -->
<script src="<?php echo e(url('/')); ?>/admin/plugins/jquery/jquery.min.js"></script>
<script src="<?php echo e(url('/')); ?>/frontend/library/js/app-min.js"></script>
<script src="<?php echo e(url('/')); ?>/admin/plugins/toastr/toastr.min.js"></script>
<script>
    $('#subscriberSubmit').on('click',function (){

        var email = document.getElementById('NewsLEmail').value ;
        $.ajax({
            url: '<?php echo e(route('save_subscriber')); ?>',
            type: 'POST',
            data : {
                "_token" : "<?php echo e(@csrf_token()); ?>",
                "email" : email,
            },
            success: function (responce) {
                console.log(responce)
                if (responce.status === 200){
                    toastr.options =
                        {
                            "closeButton" : true,
                            "timeout" : 5000,
                        }
                    toastr.success(responce.message)
                }else{
                    toastr.options =
                        {
                            "closeButton" : true,
                            "timeout" : 5000,
                        }
                    printErrorMsg(responce.error)
                }
            }
        })
        function printErrorMsg (msg) {
            $(".print-error-msg").find("ul").html('');
            $(".print-error-msg").css('display','block');
            $.each( msg, function( key, value ) {
                toastr.error(value)
            });
        }
    })
</script>
<?php echo $__env->yieldPushContent('script'); ?>
</body>
</html>
<?php /**PATH F:\xampp\htdocs\e122699\resources\views/frontend/layout/master.blade.php ENDPATH**/ ?>