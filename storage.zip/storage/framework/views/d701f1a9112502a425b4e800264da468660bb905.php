<title>JJbox.uk - ALL NEWS</title>
<?php $__env->startSection('content'); ?>

<!--inner-banner-->
<section id="banner" class="inner-backg">
    <div class="inner-pg-banner">
        <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-inner-banner.webp" alt="inner-banner" loading="lazy">
        <div class="inner-ban-head">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page"><i class="fal fa-chevron-right"></i><a>latest news</a></li>
                </ol>
            </nav>
        </div>
    </div>
</section>
<!--inner-banner-end-->

<!-- latest news section  -->

<section class="latest-news section-area">
    <div class="container">
        <div class="row">
            <div class="col-md-7 col-lg-8">
              <div class="top-news" style="background-image: url(frontend/assets/images/jj-banner.webp);">
                <div class="top-news-txt">
                    <div class="h4">news title...</div>
                    <p class="p1">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Distinctio, excepturi.</p>
                    <a href="<?php echo e(route('news_details')); ?>" class="btn1">read more</a>
                </div>
              </div>
            </div>
            <div class="col-md-5 col-lg-4">
                <div class="right-news">
                   <div class="h6">grab the latest news</div>
                   <ul class="grab-news">
                    <li>
                        <ul class="g-news">
                            <li><img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-trand-event.webp" alt="logo" loading="lazy"></li>
                            <li><a href="#"><strong>news title...</strong></a></li>
                        </ul>
                    </li>
                    <li>
                        <ul class="g-news">
                            <li><img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-trand-event.webp" alt="logo" loading="lazy"></li>
                            <li><a href="#"><strong>news title...</strong></a></li>
                        </ul>
                    </li>
                    <li>
                        <ul class="g-news">
                            <li><img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-trand-event.webp" alt="logo" loading="lazy"></li>
                            <li><a href="#"><strong>news title...</strong></a></li>
                        </ul>
                    </li>
                    <li>
                        <ul class="g-news">
                            <li><img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-trand-event.webp" alt="logo" loading="lazy"></li>
                            <li><a href="#"><strong>news title...</strong></a></li>
                        </ul>
                    </li>
                    <li>
                        <ul class="g-news">
                            <li><img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-trand-event.webp" alt="logo" loading="lazy"></li>
                            <li><a href="#"><strong>news title...</strong></a></li>
                        </ul>
                    </li>
                   </ul>
                </div>
            </div>
        </div>
        <div class="bottom-news">
            <div class="row">
                <div class="col-md-4">
                    <div class="p-category">
                        <div class="product-bottom">
                            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-latestnews-1.webp" alt="logo" loading="lazy">
                        </div>
                        <div class="product-top">
                            <div class="h5">news title..</div>
                            <span>November 16, 2016 by admin</span>
                            <p class="p2">
                              AAmet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint. Velit
                              officia consequat duis enim velit mollit. Exercitation veniam consequat sunt
                              nostrud amet.
                            </p>
                            <a href="<?php echo e(route('news_details')); ?>" class="btn1">read more</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="p-category">
                        <div class="product-bottom">
                            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-latestnews-2.webp" alt="logo" loading="lazy">
                        </div>
                        <div class="product-top">
                            <div class="h5">news title..</div>
                            <span>November 16, 2016 by admin</span>
                            <p class="p2">
                                Pesticides analysis, residual solvents, heavy metals, mycotoxins analysis,
                                terpene profiling, moisture content and microbial testing are what
                                Sci-Chem Texas Labs use to deliver a total cannabis safety profile.
                            </p>
                            <a href="<?php echo e(route('news_details')); ?>" class="btn1">read more</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="p-category">
                        <div class="product-bottom">
                            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-latestnews-3.webp" alt="logo" loading="lazy">
                        </div>
                        <div class="product-top">
                            <div class="h5">news title..</div>
                            <span>November 16, 2016 by admin</span>
                            <p class="p2">
                                Sci-Chem Texas Labs uses Innovative development and validation methods for
                                the qualitative and quantitative determination of major cannabinoids and
                                cannabis plant material.
                            </p>
                            <a href="<?php echo e(route('news_details')); ?>" class="btn1">read more</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <div class="p-category">
                        <div class="product-bottom">
                            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-latestnews-1.webp" alt="logo" loading="lazy">
                        </div>
                        <div class="product-top">
                            <div class="h5">news title..</div>
                            <span>November 16, 2016 by admin</span>
                            <p class="p2">
                              AAmet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint. Velit
                              officia consequat duis enim velit mollit. Exercitation veniam consequat sunt
                              nostrud amet.
                            </p>
                            <a href="<?php echo e(route('news_details')); ?>" class="btn1">read more</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="p-category">
                        <div class="product-bottom">
                            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-latestnews-2.webp" alt="logo" loading="lazy">
                        </div>
                        <div class="product-top">
                            <div class="h5">news title..</div>
                            <span>November 16, 2016 by admin</span>
                            <p class="p2">
                                Pesticides analysis, residual solvents, heavy metals, mycotoxins analysis,
                                terpene profiling, moisture content and microbial testing are what
                                Sci-Chem Texas Labs use to deliver a total cannabis safety profile.
                            </p>
                            <a href="<?php echo e(route('news_details')); ?>" class="btn1">read more</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="p-category">
                        <div class="product-bottom">
                            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-latestnews-3.webp" alt="logo" loading="lazy">
                        </div>
                        <div class="product-top">
                            <div class="h5">news title..</div>
                            <span>November 16, 2016 by admin</span>
                            <p class="p2">
                                Sci-Chem Texas Labs uses Innovative development and validation methods for
                                the qualitative and quantitative determination of major cannabinoids and
                                cannabis plant material.
                            </p>
                            <a href="<?php echo e(route('news_details')); ?>" class="btn1">read more</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- latest news section end -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\122687\resources\views/frontend/pages/all_news.blade.php ENDPATH**/ ?>