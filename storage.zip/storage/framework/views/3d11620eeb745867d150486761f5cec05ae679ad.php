<?php
$info = \App\Helper\admin\siteInformation::siteInfo();
$contact_info = \App\Models\ContactInfo::where('status','Active')->first();
?>
<div class="top">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-lg-4">
                <a href="<?php echo e(route('home')); ?>"><img src="" alt="" loading="lazy" class="logo"></a>
                <ul class="info">
                    <li><span><?php echo e($contact_info['address'] ?? ""); ?></span></li>
                    <li><a href="mailto:<?php echo e($contact_info['email'] ?? ""); ?>"><span><?php echo e($contact_info['email'] ?? ""); ?></span></a></li>
                    <?php if(!empty($contact_info['phone'])): ?>
                    <li>
                        <a href="tel:<?php echo e($contact_info['phone']?? ""); ?>">
                            <span>
                            (<?php echo e($contact_info['phone_code']); ?>)<?php echo e(substr($contact_info['phone'],0,4)); ?> <?php echo e(substr($contact_info['phone'],5,strlen($contact_info['phone']))); ?>

                            </span>
                        </a>
                    </li>
                    <?php endif; ?>
                    <li><a href="<?php echo e($contact_info['website'] ?? ""); ?>" target="_blank"><span><?php echo e($contact_info['website'] ?? ""); ?></span></a></li>
                </ul>
            </div>
            <div class="col-md-6 col-lg-3">
                <h5>Quick links</h5>
                <ul>
                    <li><a href="<?php echo e(route('products')); ?>">Products</a></li>
                    <li><a href="<?php echo e(route('abouts')); ?>">Our Story & team</a></li>
                    <li><a href="<?php echo e(route('services')); ?>">Services</a> </li>
                    <li><a href="<?php echo e(route('contacts')); ?>">Contact Us</a></li>
                    <li><a href="<?php echo e(route('career')); ?>">Career whith us</a></li>
                </ul>
            </div>

            <?php
            $newsLater = \App\Models\Cms::where('key','news_later')
                ->where('status','Active')->select('title','description')->first();
            /*if(!empty($newsLater)) {
                $explode = explode(' ', $newsLater['title']);
                if (count($explode) > 1) {
                    $p_title1 = $explode[0];
                    unset($explode[0]);
                    $p_title2 = implode(' ', $explode);

                }else{
                    $p_title1 = implode(' ', $explode);
                    $p_title2 = ' ';
                }
            }*/
            ?>
            <div class="col-md-6 col-lg-5">
                <?php if(!empty($newsLater)): ?>
                <h5><?php echo e($newsLater['title'] ?? ""); ?></h5>
                    <div class="form-group">
                        <?php echo csrf_field(); ?>
                        <input type="text" id="NewsLEmail" class="form-control" placeholder="Enter E-mail Address">
                        <button class="btn" id="subscriberSubmit">SUBMIT</button>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<div class="copyright">
    <?php if(!empty($info['copy_right'])): ?>
    <p><?php echo e($info['copy_right']); ?></p>
    <?php endif; ?>
</div>

<?php /**PATH F:\xampp\htdocs\e122699\resources\views/frontend/layout/footer.blade.php ENDPATH**/ ?>