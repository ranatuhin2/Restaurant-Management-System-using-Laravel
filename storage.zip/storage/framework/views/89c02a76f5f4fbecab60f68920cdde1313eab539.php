<?php $__env->startSection('content'); ?>


    <div class="content-wrapper" style="min-height: 357px;">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Site Contact-Us Details</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin::dashboard')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active">Site Contact-Us Details</li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Site Contact-Us Details</h3>
                                <h3 class="card-title" style="float: right!important;">
                                    <a href="<?php echo e(route('admin::contactdetails.add')); ?>" class="btn btn-success"><i
                                            class="fa fa-plus" aria-hidden="true"></i> Add New Value</a>
                                </h3>
                            </div>
                            <?php if(session()->has('success')): ?>
                                <div class="alert alert-success">
                                    <button id="bannerClose" class="btn border-0 p-0"></button>
                                    <?php echo e(session()->get('success')); ?>


                                </div>
                            <?php elseif(session()->has('error')): ?>
                                <div class="alert alert-danger">
                                    <button id="bannerClose" class="btn border-0 p-0"></button>
                                    <?php echo e(session()->get('error')); ?>


                                </div>
                        <?php endif; ?>
                        <!-- /.card-header -->
                            <div class="card-body">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                    <tr>
                                        <th style="text-align: center;">Key</th>
                                        <th style="text-align: center;">Value</th>
                                        <th style="text-align: center;">Status</th>
                                        <th style="text-align: center;">Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php if(!empty($data)): ?>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td style="text-align: center;">
                                                    <?php echo e($values['key']); ?>

                                                </td>
                                                <td style="text-align: center;">
                                                    <?php echo e($values['value']); ?>

                                                </td>
                                                <td style="text-align: center;">
                                                     <span id="status<?php echo e($values->id); ?>">
    <?php if($values->status == 1){?>
    <a href="javascript:active_inactive('<?php echo $values->id; ?>',1);"
       class="btn btn-success btn-sm" ><i class='fas fa-check-circle' ></i> </a>&emsp;
    <?php } else{?>
    <a href="javascript:active_inactive('<?php echo $values->id; ?>',0);"
       class="btn btn-warning btn-sm"><i class='fas fa-ban' ></i>
 </a>&emsp;
    <?php } ?>
</span>
                                                </td>
                                                <td style="text-align: center;">
                                                    <a href="<?php echo e(route('admin::contactdetails.edit',['id'=>$values['id']])); ?>"
                                                       class="btn btn-warning btn-sm"><i class="fa fa-edit"></i> </a>
                                                    <a href="<?php echo e(route('admin::contactdetails.delete', ['id' => $values['id']])); ?>"
                                                       class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    </tbody>

                                </table>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
    <?php $__env->startPush('scripts'); ?>
        <script>

            function active_inactive(id,status) {
                console.log(status);
                $.ajax({
                    type: "post",
                    url: '<?php echo e(url('admin::contactdetails.active')); ?>',
                    data: {
                        _token: '<?php echo csrf_token();?>',
                        id: id,
                        status: status
                    },
                    success: function (data) {

                        var resp = JSON.parse(data);
                        $('#status' + resp.id).html(resp.html);
                        $(document).find('.child #status' + resp.id).html(resp.html);
                    }

                });
            }
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\122687\resources\views/admin/pages/contactus/viewcontact.blade.php ENDPATH**/ ?>