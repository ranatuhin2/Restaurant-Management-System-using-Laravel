<?php
    $info = \App\Helper\admin\siteInformation::siteInfo();
    $segment = Request::segment(1);
?>
    <div class="nav_area">
        <div class="container">
            <div class="row">
                <nav class="navbar navbar-expand-xl navbar-light w-100">
                    <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
                        <img src="<?php echo e($info['site_logo'] ?? ""); ?>" alt="Logo" loading="lazy">
                    </a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse"
                            data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                            aria-expanded="false" aria-label="Toggle navigation">
                        <span></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav ml-auto">
                            <li class="nav-item  <?php if(url()->current() == route('home')): ?> active <?php endif; ?>">
                                <a class="nav-link" href="<?php echo e(route('home')); ?>">Home <span class="sr-only">(current)</span></a>
                            </li>
                            <li class="nav-item <?php if(in_array($segment,['products','product-details'])): ?> active <?php endif; ?>">
                                <a class="nav-link" href="<?php echo e(route('products')); ?>">Products</a>
                            </li>
                            <li class="nav-item <?php if(url()->current() == route('services')): ?> active <?php endif; ?>">
                                <a class="nav-link" href="<?php echo e(route('services')); ?>">Services</a>
                            </li>
                            <li class="nav-item <?php if(url()->current() == route('abouts')): ?> active <?php endif; ?>">
                                <a class="nav-link" href="<?php echo e(route('abouts')); ?>">Our Story and Team</a>
                            </li>
                            <li class="nav-item <?php if(url()->current() == route('career')): ?> active <?php endif; ?>">
                                <a class="nav-link" href="<?php echo e(route('career')); ?>">Career</a>
                            </li>
                            <li class="nav-item <?php if(url()->current() == route('contacts')): ?> active <?php endif; ?>">
                                <a class="nav-link" href="<?php echo e(route('contacts')); ?>">Contact Us</a>
                            </li>
                        </ul>
                    </div>

                </nav>
            </div>
        </div>
    </div>
<?php /**PATH F:\xampp\htdocs\e122699\resources\views/frontend/layout/header.blade.php ENDPATH**/ ?>