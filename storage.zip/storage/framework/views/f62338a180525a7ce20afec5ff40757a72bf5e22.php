<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="card-header">
            <a class="btn btn-info float-right btn-sm" href="<?php echo e(route('admin::faq.index')); ?>">
                <i class="fa fa-plus-circle"></i> View </a>
        </div>


        <div class="card card-warning">
            <div class="card-header">
                <h3 class="card-title"> Add Details</h3>
            </div>
            <?php if(session()->has('success')): ?>
                <div class="alert alert-success">
                    <button id="bannerClose" class="btn border-0 p-0"></button>
                    <?php echo e(session()->get('success')); ?>


                </div>
            <?php endif; ?>
            <!-- /.card-header -->
            <div class="card-body">
                <form action="<?php echo e(route('admin::faq.submit')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>


                    <div class="row">


                        <div class="col-sm-12">

                            <div class="form-group">
                                <label>Question</label>
                                <input type="text" name="question" class="form-control" value="<?php echo e(old('question')); ?>" placeholder="Enter ...">
                            </div>
                            <?php if($errors->has('question')): ?>
                                <span class="alert alert-danger"><?php echo e($errors->first('question')); ?></span>
                            <?php endif; ?>


                        </div>
                    </div>
                    <br>


                    <div class="col-sm-12">

                        <div class="form-group">
                            <label>Answer</label>
                            <textarea name="answer" class="summernote" rows="6" cols="50" 
                            placeholder="Enter ..."><?php echo e(old('answer')); ?></textarea>
                        </div>
                        <?php if($errors->has('answer')): ?>
                            <span class="alert alert-danger"><?php echo e($errors->first('answer')); ?></span>
                        <?php endif; ?>
                    </div>
            </div>


            <!-- input states -->







            <div class="row">

                <div class="col-md-12">
                    <div class="form-group" style="text-align:center">
                        <input type="submit" value="Submit" class="btn btn-primary">

                    </div>
                </div>


            </div>
            </form>
        </div>
        <!-- /.card-body -->
    </div>
    </div>



    <?php $__env->startPush('scripts'); ?>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\122687\resources\views/admin/pages/quicklinks/faq/add.blade.php ENDPATH**/ ?>