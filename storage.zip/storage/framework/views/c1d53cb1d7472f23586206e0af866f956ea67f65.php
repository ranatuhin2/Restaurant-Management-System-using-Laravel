
<?php $__env->startSection('content'); ?>
<div class="container">
    <header class="modal-header">
</header>
<!-- <?php if(session('message')): ?>
<?php echo e((session('message'))); ?>

<?php endif; ?> -->

<div class="container d-flex justify-content-center">
<?php if(isset($abouts)): ?>
<form action="<?php echo e(route('admin::service-update')); ?>" method="post" style="width:50vw; min-width:300px;" enctype="multipart/form-data">
<div class="form-group">
  <input type="hidden" class="form-control" name="id" value="<?php echo e($abouts->id); ?>">
  </div>
  <?php echo csrf_field(); ?>
  <div class="form-group">
      <label class="form-label">Title</label> 
      <input type="text" class="form-control" name="title" value="<?php echo e($abouts->title); ?>"  >
    </div>
  
      <div class="form-group">
      <label class="form-label">Description</label> 
      <input type="text" class="form-control" name="description" value="<?php echo e($abouts->description); ?>">
    </div>
    
    <div class="form-group">
      <label class="form-label">Image</label> 
      <input type="file" class="form-control"  name="image" >
      <br>
      <img src="<?php echo e(url('/')); ?>/upload_file/<?php echo e($abouts->image); ?>" height="55px" >
      </div>
    <div class="form-group">
      <button class="btn btn-sm btn-primary">Submit</button>
    </div>

</form>
</div>
<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\adminTempLaravel8\adminTempLaravel8\resources\views/admin/pages/service/edit.blade.php ENDPATH**/ ?>