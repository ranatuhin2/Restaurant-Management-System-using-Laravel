<?php
    $info = \App\Helper\admin\siteInformation::siteInfo();
?>

<style>
    .os-host-overflow {
        overflow: initial !important;
    }
</style>
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="index3.html" class="brand-link">
        <img src="<?php echo e(url('/')); ?>/admin/dist/img/AdminLTELogo.png" alt="AdminLTE Logo"
            class="brand-image img-circle elevation-3" style="opacity: .8">
        <span class="brand-text font-weight-light"><?php echo e($info['site_name']); ?></span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user panel (optional) -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
                <img src="<?php echo e(asset('upload/images/profile/' . Auth::user()['profile_picture'])); ?>"
                    class="img-circle elevation-2" alt="User Image">
            </div>
            <div class="info">
                <a href="<?php echo e(route('admin::profile', ['name' => Auth::user()['slug_name']])); ?>"
                    class="d-block"><?php echo e(Auth::user()['name']); ?></a>
            </div>
        </div>
        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                data-accordion="false">

                <li class="nav-header">MISCELLANEOUS</li>
                <li class="nav-item <?php if(url()->current() == route('admin::dashboard')): ?> menu-open <?php endif; ?>">
                    <a href="#" class="nav-link <?php if(url()->current() == route('admin::dashboard')): ?> active <?php endif; ?>">
                        <i class="nav-icon fas fa-tachometer-alt"></i>
                        <p>
                            Dashboard
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin::dashboard')); ?>" class="nav-link active">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Dashboard</p>
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="nav-item

                      <?php if(request()->routeIs('admin::i_footer.index')): ?> menu-open <?php endif; ?>">
                    <a href="#"
                        class="nav-link
                         <?php if(request()->routeIs('admin::i_footer.index')): ?> active <?php endif; ?>">
                        <i class="nav-icon fa fa-cog"></i>
                        <p>
                            Site-Logo
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('admin::slider.index')); ?>"
                        class="nav-link <?php if(request()->routeIs('admin::slider.*')): ?> active <?php endif; ?>">
                        <i class="nav-icon fa fa-picture-o"></i>
                        <p> Slider Images</p>
                    </a>
                </li>
                
                    
                <li class="nav-item">
                    <a href="<?php echo e(route('admin::aboutus.index')); ?>"
                        class="nav-link <?php if(request()->routeIs('admin::aboutus.*')): ?> active <?php endif; ?>">
                        <i class="nav-icon fa fa-buysellads"></i>
                        <p> AboutUs</p>
                    </a>
                </li>

                
                <li
                    class="nav-item <?php if(url()->current() == route('admin::viewrequest')): ?> menu-open
                                            <?php elseif(request()->routeIs('admin::contactdetails.*')): ?> menu-open <?php endif; ?>">


                    <a href="#"
                        class="nav-link <?php if(url()->current() == route('admin::viewrequest')): ?> active
                                                                    <?php elseif(request()->routeIs('admin::contactdetails.*')): ?> active <?php endif; ?>">
                        <i class="nav-icon fas fa-handshake"></i>
                        <p>
                            Contact Us
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin::viewrequest')); ?>"
                                class="nav-link <?php if(url()->current() == route('admin::viewrequest')): ?> active <?php endif; ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>View Messages</p>
                            </a>


                            <a href="<?php echo e(route('admin::contactdetails.view')); ?>"
                                class="nav-link   <?php if(request()->routeIs('admin::contactdetails.*')): ?> active <?php endif; ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Site Contact Info</p>
                            </a>
                        </li>
                    </ul>
                </li>















                <li class="nav-item">
                    <a href="<?php echo e(route('admin::d_footer.index')); ?>"
                        class="nav-link
                     <?php if(request()->routeIs('admin::d_footer.index')): ?> active <?php endif; ?>">
                        <i class="nav-icon fab fa-facebook-f"></i>
                        <p>Footer Description</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('admin::faq.index')); ?>"
                        class="nav-link
                     <?php if(request()->routeIs('admin::faq.*')): ?> active <?php endif; ?>">
                        <i class="nav-icon fa fa-question-circle"></i>
                        <p>FAQ</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('admin::terms.index')); ?>"
                        class="nav-link
                     <?php if(request()->routeIs('admin::terms.*')): ?> active <?php endif; ?>">
                        <i class="nav-icon fas fa-file-contract"></i>
                        <p>Terms of Use</p>
                    </a>
                </li>

            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside>
<?php /**PATH C:\xampp\htdocs\122687\resources\views/admin/layout/leftmenu.blade.php ENDPATH**/ ?>