<?php $__env->startSection('content'); ?>
    <div class="inner-banner">
        <img src="<?php echo e(url('/')); ?>/frontend/assets/images/guitar.webp" alt="">
        <div class="banner-content">
            <h3>Contact Us</h3>
            <ol class="breadcrumb">


                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a>

                </li>





                <li class="breadcrumb-item active" aria-current="page">Contact Us</li>


            </ol>
        </div>
    </div>
    <div class="contact_page gap">
    <div class="container">
        <h3 class="head">Contact Us</h3>
        <div class="form-area">
            <div class="form-group">
                <input type="text" class="form-control" placeholder="First Name *">
            </div>
            <div class="form-group">
                <input type="text" class="form-control" placeholder="Last Name *">
            </div>
            <div class="form-group">
                <input type="text" class="form-control" placeholder="Email *">
            </div>
            <div class="form-group">
                <input type="text" class="form-control" placeholder="Phone *">
            </div>
            <div class="form-group">
                <input type="text" class="form-control" placeholder="Subject *">
            </div>
            <div class="form-group">
                <input type="text" class="form-control" placeholder="Company *">
            </div>
            <textarea class="form-control" placeholder="Message *"></textarea>
            <button class="btn">Send</button>
        </div>
        <div class="map">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d27487.162509525122!2d-1.9072030641740945!3d52.487375765129926!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4870942d1b417173%3A0xca81fef0aeee7998!2sBirmingham%2C%20UK!5e0!3m2!1sen!2sin!4v1653549174779!5m2!1sen!2sin" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\e122699\resources\views/frontend/pages/contact.blade.php ENDPATH**/ ?>