<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="card-header">
            <a class="btn btn-info float-right btn-sm" href="<?php echo e(route('admin::contactdetails.view')); ?>">
                <i class="fa fa-plus-circle"></i> View </a>
        </div>


        <div class="card card-warning">
            <div class="card-header">
                <h3 class="card-title"> Add Details</h3>
            </div>
            <?php if(session()->has('success')): ?>
                <div class="alert alert-success">
                    <button id="bannerClose" class="btn border-0 p-0"></button>
                    <?php echo e(session()->get('success')); ?>


                </div>
        <?php endif; ?>
        <!-- /.card-header -->
            <div class="card-body">
                <form action="<?php echo e(route('admin::contactdetails.submit')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>


                    <div class="row">


                        <div class="col-sm-12">

                            <div class="form-group">
                                <label>Key</label>
                                <select name="key" class="form-control" id="key">
                                    <option selected disabled>- Select Proper Key -</option>
                                    <option value="address">Address</option>
                                    <option value="phone">Phone</option>
                                    <option value="email">Email</option>

                                </select>
                            </div>
                            <?php if($errors->has('key')): ?>
                                <span class="alert alert-danger"><?php echo e($errors->first('key')); ?></span>
                            <?php endif; ?>


                        </div>


                    </div>
                    <br>


                    <div class="col-sm-12" id="value_hide">

                        <div class="form-group" id="change">
                            <label>Value</label>
                            <input type="text" name="value" class="form-control" placeholder="Enter ...">
                        </div>
                        <?php if($errors->has('value')): ?>
                            <span class="alert alert-danger"><?php echo e($errors->first('value')); ?></span>
                        <?php endif; ?>
                    </div>


                    <!-- input states -->











                    <div class="row">

                        <div class="col-md-12">
                            <div class="form-group" style="text-align:center">
                                <input type="submit" value="Submit" class="btn btn-primary">

                            </div>
                        </div>


                    </div>
                </form>
            </div>
            <!-- /.card-body -->
        </div>
    </div>



    <?php $__env->startPush('scripts'); ?>
        <script>
            $('#value_hide').hide();
            $("#key").change(function () {
                var val = $('#key').val();

                if (val == 'address') {
                    $('#value_hide').show();
                    $("#value_hide").html('  <div class="form-group" id="change">\n' +
                        '                            <label>Address</label>\n' +
                        '                            <input type="text" name="value" class="form-control" placeholder="Enter address...">\n' +
                        '                        </div>' +
                        ' <?php if($errors->has('value')): ?>' +
                        '                            <span class="alert alert-danger"><?php echo e($errors->first('value')); ?></span>\n' +
                        '                        <?php endif; ?>');
                } else if (val == 'email') {
                    $('#value_hide').show();
                    $("#value_hide").html('  <div class="form-group" id="change">\n' +
                        '                            <label>Email</label>\n' +
                        '                            <input type="email" name="value" class="form-control" placeholder="Enter email ...">' +
                        '                        </div>' +
                        ' <?php if($errors->has('value')): ?>' +
                        '                        \'                            <span class="alert alert-danger"><?php echo e($errors->first('value')); ?></span>\' +\n' +
                        '                        \'                        <?php endif; ?>');
                } else if (val == 'phone') {
                    $('#value_hide').show();
                    $("#value_hide").html('  <div class="form-group" id="change">\n' +
                        '                            <label>Phone</label>\n' +
                        '                            <input type="tel" name="value" class="form-control" placeholder="Enter phone details ...">\n' +
                        '                        </div>' +
                        ' <?php if($errors->has('value')): ?>\n'  +
                        '                        \'                            <span class="alert alert-danger"><?php echo e($errors->first('value')); ?></span>\' +\n' +
                        '                        \'                        <?php endif; ?>');

                }
            });


        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\122687\resources\views/admin/pages/contactus/add.blade.php ENDPATH**/ ?>