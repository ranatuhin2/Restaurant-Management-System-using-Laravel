<?php $__env->startSection('content'); ?>
    <!--inner-banner-->
    <section id="banner" class="inner-backg">
        <div class="inner-pg-banner">
            <img src="<?php echo e(url('/')); ?>/frontend/assets/images/jj-inner-banner.webp" alt="inner-banner" loading="lazy">
            <div class="inner-ban-head">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('index')); ?>">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page"><i
                                class="fal fa-chevron-right"></i><a>FAQ</a></li>
                    </ol>
                </nav>
            </div>
        </div>
    </section>
    <!--inner-banner-end-->
    <?php
    $test = \App\Models\QuestionHeading::latest()->first();
    $data = \App\Models\AskedQuestion::where('status',1)->get();
    ?>

    <!-- faq page  -->
    <div class="help-center">
        <div class="container">
            <div class="h3"><?php echo e($test->heading); ?></div>
            <p class="p1"><?php echo $test->description; ?></p>

            <div class="qes-ans">
                <div class="faq-block">
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="h5 faq-que"><?php echo e($value->question); ?></div>
                        <div class="p1 faq-ans">
                            <?php echo $value->answer; ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>


            </div>
        </div>
        <!-- faq page end -->
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\122687\resources\views/frontend/pages/faq.blade.php ENDPATH**/ ?>