<?php
    $segment4 = Request::segment(4);
    $segment5 = Request::segment(5);
    $info = \App\Helper\admin\siteInformation::siteInfo();
?>

<style>
    .os-host-overflow {
        overflow: initial !important;
    }
</style>
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="<?php echo e(route('admin::dashboard')); ?>" class="brand-link">
        <img src="<?php echo e($info['site_logo']); ?>" alt="AdminLTE Logo"
            class="brand-image img-circle elevation-3" style="opacity: .8">
        <span class="brand-text font-weight-light"><?php echo e($info['site_name']); ?></span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user panel (optional) -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
                <img src="<?php echo e(asset('upload/images/profile/' . Auth::user()['profile_picture'])); ?>"
                    class="img-circle elevation-2" alt="User Image">
            </div>
            <div class="info">
                <a href="<?php echo e(route('admin::profile', ['name' => Auth::user()['slug_name']])); ?>"
                    class="d-block"><?php echo e(Auth::user()['name']); ?></a>
            </div>
        </div>
        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                data-accordion="false">


                <li class="nav-item <?php if(url()->current() == route('admin::dashboard')): ?> menu-open <?php endif; ?>">
                    <a href="#" class="nav-link <?php if(url()->current() == route('admin::dashboard')): ?> active <?php endif; ?>">
                        <i class="nav-icon fas fa-tachometer-alt"></i>
                        <p>
                            Dashboard
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin::dashboard')); ?>" class="nav-link  <?php if(url()->current() == route('admin::dashboard')): ?> active <?php endif; ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Dashboard</p>
                            </a>
                        </li>
                    </ul>
                </li>
                
                <li class="nav-item">
                    <a href="<?php echo e(route('admin::banner')); ?>"
                       class="nav-link
                            <?php if(in_array($segment4, ['banner','add-banner','edit-banner'])): ?> active <?php endif; ?>">
                        <i class="fa fa-image nav-icon"></i>
                        <p>Banner</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('admin::about')); ?>"
                       class="nav-link
                            <?php if(in_array($segment4, ['about','edit-about'])): ?> active <?php endif; ?>">
                        <i class="fa fa-bars nav-icon"></i>
                        <p>about</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('admin::testimonials')); ?>"
                       class="nav-link
                            <?php if(in_array($segment4, ['testimonials','add-testimonial','edit-testimonial'])  ||
                                $segment5 == 'testimonial'): ?>
                                active <?php endif; ?>">
                        <i class="fa fa-comment nav-icon"></i>
                        <p>Testimonials</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('admin::team_member')); ?>"
                       class="nav-link
                            <?php if(in_array($segment4, ['team-member','add-team-member','edit-team-member']) ||
                                $segment5 == 'our_team'): ?>
                                active  <?php endif; ?>">
                        <i class="fas fa-users-cog nav-icon"></i>
                        <p>team member</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('admin::subscribers')); ?>"
                       class="nav-link
                            <?php if(in_array($segment4, ['subscribers'])): ?> active  <?php endif; ?>">
                        <i class="fa fa-users nav-icon"></i>
                        <p>Subscribers</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('admin::contact')); ?>"
                       class="nav-link
                            <?php if(in_array($segment4, ['contact','add-contact','edit-contact'])): ?> active <?php endif; ?>">
                        <i class="fa fa-cog nav-icon"></i>
                        <p>Contact Info</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('admin::information')); ?>"
                       class="nav-link
                            <?php if(in_array($segment4, ['information','add-information','information-edit'])): ?> active <?php endif; ?>">
                        <i class="fa fa-cog nav-icon"></i>
                        <p>General Settings</p>
                    </a>
                </li>
               
            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside>
<?php /**PATH F:\xampp\htdocs\e122699\resources\views/admin/layout/leftmenu.blade.php ENDPATH**/ ?>